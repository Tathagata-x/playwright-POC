// HomePageTests.java
package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import factory.DriverFactory;

import org.testng.Assert;
import org.testng.annotations.*;
import pages.HomePageElements;
import utils.WebActions;

public class HomePageTests {
    HomePageElements homePage;

	/*
	 * @BeforeMethod public void setup() { String browser =
	 * WebActions.getProperty("browser"); DriverFactory.initializeDriver(browser);
	 * homePage = new HomePageElements(DriverFactory.getPage()); }
	 */

    @Test
    public void testHomePageHeader() {
        homePage.verifyHeaderDisplay();
    }

    @Test
    public void testNavigationToChangeRequest() {
        homePage.menuItemClick();
        homePage.filterMenuItem();
        homePage.clickOnSubCategory();
        homePage.awaitingChgReqPage();
    }

	@AfterMethod
    public void tearDown() {
        DriverFactory.closeDriver();
    }
}
