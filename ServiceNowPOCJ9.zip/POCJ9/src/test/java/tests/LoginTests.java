// LoginTests.java
package tests;

import org.testng.annotations.Test;
import factory.DriverFactory;
import org.testng.annotations.*;
import pages.LoginPageSerivceNow;
import utils.WebActions;

public class LoginTests {
    LoginPageSerivceNow loginPage;

    @BeforeMethod
    public void setup() {
        String browser = WebActions.getProperty("browser");
        DriverFactory.initializeDriver(browser);
        loginPage = new LoginPageSerivceNow(DriverFactory.getPage());
    }

    @Test
    public void testSuccessfulLogin() {
        loginPage.navigateToUrl("url");
        loginPage.enterUsername("username");
        loginPage.enterPassword("password");
        loginPage.clickLogin();
        loginPage.verifyProfilePage();
    }

	/*
	 * @AfterMethod public void tearDown() { DriverFactory.closeDriver(); }
	 */
}