package listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ExtentReportListener implements ITestListener {
    private static ExtentReports extent = new ExtentReports();
    private static ExtentTest test;

    static {
        // Setup the report to save in the target/extent-reports folder
        ExtentSparkReporter spark = new ExtentSparkReporter("target/extent-reports/extent-report.html");
        extent.attachReporter(spark);
    }

    @Override
    public void onTestStart(ITestResult result) {
        // Create a test for the started method
        test = extent.createTest(result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        // Log success when the test passes
        test.log(Status.PASS, "Test passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        // Log failure with the reason when the test fails
        test.log(Status.FAIL, "Test failed");
        test.fail(result.getThrowable());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        // Log skipped tests
        test.log(Status.SKIP, "Test skipped");
    }

    @Override
    public void onFinish(ITestContext context) {
        // This is the correct signature for onFinish, accepting ITestContext as a parameter
        extent.flush();  // Write the final report when all tests are complete
    }
}
