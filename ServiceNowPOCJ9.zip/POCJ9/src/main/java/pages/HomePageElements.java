package pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitForSelectorState;

import utils.WebActions;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import com.microsoft.playwright.ElementHandle.WaitForElementStateOptions;



public class HomePageElements {
	private Page page;
    private final Locator HEADEREXCLAIM;
    private final Locator MENUITEM_ALL;
    private final Locator FILTER;
    private final Locator CHANGE;
    private final Locator CREATE_NEW;
    private final Locator HOME_ADD;
    private final Locator New_CHG_Request_HomeAdd;
    private final Locator CREATE_CHG_RQ;
    private final Locator CLOSE_TAB;
    public HomePageElements (Page page) {
        this.page = page;
        this.HEADEREXCLAIM = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Hello IVS!"));
        this.MENUITEM_ALL = page.getByLabel("All", new Page.GetByLabelOptions().setExact(true));
        this.FILTER = page.getByPlaceholder("Filter");
        this.CHANGE = page.getByLabel("Change", new Page.GetByLabelOptions().setExact(true));
        this.HOME_ADD = page.getByLabel("Add", new Page.GetByLabelOptions().setExact(true));
        this.CREATE_NEW = page.getByLabel("Create New 1 of");
        this.CREATE_CHG_RQ = page.getByLabel("Primary").getByText("Create change request");
        this.New_CHG_Request_HomeAdd = page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("New Change Request"));
        this.CLOSE_TAB = page.getByLabel("Close Tab Create change");
        
    }
    public boolean verifyHeaderDisplay() {
    	assertThat(HEADEREXCLAIM).containsText("Hello");
    	return WebActions.waitUntilElementDisplayed(this.HEADEREXCLAIM, 60);
    }
    public void home_plus_button() {
    	HOME_ADD.click();
    	New_CHG_Request_HomeAdd.click();
    	
    	CLOSE_TAB.click();
    	
        //page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("New Change Request")).click();
        
    }
    public void menuItemClick() {
    	MENUITEM_ALL.click();
    }
    public void filterMenuItem() {
    	FILTER.focus();
    	page.waitForTimeout(3000);
    	FILTER.fill("Change");
    	//assertThat(CHANGE).isVisible();
    	CHANGE.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    	CREATE_NEW.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(10000)); // 10-second timeout
    }

    public void filterSubCategory() {
        // Ensure the filter input is focused and filled
        FILTER.focus();
        page.waitForTimeout(500); // Small delay
        FILTER.fill("Change");

        // Wait for the dropdown to become visible before pressing ArrowDown
        CREATE_NEW.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5000));
        
        // Click to ensure dropdown is active
        CREATE_NEW.click();

        // Press the Arrow Down key three times
        for (int i = 0; i < 3; i++) {
            page.keyboard().press("ArrowDown");
            page.waitForTimeout(300); // Reduce wait time for efficiency
        }
    }

    public void clickOnSubCategory() {
    	CREATE_NEW.focus();
    	CREATE_NEW.press("Enter");
    }
    public void awaitingChgReqPage() {
    	CREATE_CHG_RQ.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    	assertThat(CREATE_CHG_RQ).isVisible();
    }
        
    
}
