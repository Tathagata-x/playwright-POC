// Updated DriverFactory.java
package factory;

import java.nio.file.Paths;
import java.util.UUID;

import com.microsoft.playwright.*;
import utils.WebActions;

public class DriverFactory {
    private static ThreadLocal<Browser> browserThreadLocal = new ThreadLocal<>();
    private static ThreadLocal<BrowserContext> contextThreadLocal = new ThreadLocal<>();
    private static ThreadLocal<Page> pageThreadLocal = new ThreadLocal<>();

    public static Browser getBrowser() {
        return browserThreadLocal.get();
    }

    public static BrowserContext getContext() {
        return contextThreadLocal.get();
    }

    public static Page getPage() {
        return pageThreadLocal.get();
    }

    public static void initializeDriver(String browserName) {
        BrowserType browserType;
        boolean headless = Boolean.parseBoolean(WebActions.getProperty("headless"));

        switch (browserName.toLowerCase()) {
            case "firefox":
                browserType = Playwright.create().firefox();
                break;
            case "chrome":
                browserType = Playwright.create().chromium();
                break;
            case "webkit":
                browserType = Playwright.create().webkit();
                break;
            default:
                throw new IllegalArgumentException("Invalid browser: " + browserName);
        }

        Browser browser = browserType.launch(new BrowserType.LaunchOptions().setHeadless(headless));
        BrowserContext context = browser.newContext();
        context.tracing().start(new Tracing.StartOptions().setScreenshots(true).setSnapshots(true));
        Page page = context.newPage();

        browserThreadLocal.set(browser);
        contextThreadLocal.set(context);
        pageThreadLocal.set(page);
    }

    public static void closeDriver() {
        Page page = pageThreadLocal.get();
        if (page != null) {
            page.context().tracing().stop(new Tracing.StopOptions()
                .setPath(Paths.get("target/trace/" + UUID.randomUUID() + ".zip")));
            page.close();
            page.context().close();
            page.context().browser().close();
            pageThreadLocal.remove();
            contextThreadLocal.remove();
            browserThreadLocal.remove();
        }
    }
}