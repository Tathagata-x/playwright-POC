package com.qa.utils;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Wait {

    private static final Logger logger = LoggerFactory.getLogger(Wait.class);
    private static final int WAIT_TIMEOUT = 15;

    public void waitForElementToDisplay(WebDriver driver, WebElement element) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(WAIT_TIMEOUT))
                    .until(ExpectedConditions.visibilityOf(element)); // More concise
            logger.info("{} Element is displayed", element);
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for element to display: {}", element, e);
            // Consider throwing a custom exception or re-throwing the TimeoutException
            throw new TimeoutException("Timeout waiting for element to display: " + e.getMessage(), e);
        }
    }

    public void waitForElementToEnable(WebDriver driver, WebElement element) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(WAIT_TIMEOUT))
                    .until(ExpectedConditions.elementToBeClickable(element)); // Wait for clickable (enabled and displayed)
            logger.info("{} Element is enabled", element);
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for element to enable: {}", element, e);
            throw new TimeoutException("Timeout waiting for element to enable: " + e.getMessage(), e);
        }
    }

    public void waitAndClick(By locator, WebDriver driver) {
        try {
            WebElement element = new WebDriverWait(driver, Duration.ofSeconds(WAIT_TIMEOUT))
                    .until(ExpectedConditions.elementToBeClickable(locator));
            element.click();
            logger.info("Clicked element: {}", locator);
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for element to be clickable: {}", locator, e);
            throw new TimeoutException("Timeout waiting for element to be clickable: " + e.getMessage(), e);
        }
    }

    public WebElement waitForElementVisible(By locator, WebDriver driver) {
        try {
            WebElement element = new WebDriverWait(driver, Duration.ofSeconds(WAIT_TIMEOUT))
                    .until(ExpectedConditions.visibilityOfElementLocated(locator));
            logger.info("Element is visible: {}", locator);
            return element;
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for element to be visible: {}", locator, e);
            throw new TimeoutException("Timeout waiting for element to be visible: " + e.getMessage(), e);
        }
    }

    public WebElement fluentWait(final By locator, WebDriver driver) {
        FluentWait<WebDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(30))
                .pollingEvery(Duration.ofSeconds(5))
                .ignoring(NoSuchElementException.class);

        try {
            WebElement element = wait.until(new Function<WebDriver, WebElement>() {
                public WebElement apply(WebDriver driver) {
                    return driver.findElement(locator);
                }
            });
            logger.info("Element found using fluent wait: {}", locator);
            return element;
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for element using fluent wait: {}", locator, e);
            throw new TimeoutException("Timeout waiting for element using fluent wait: " + e.getMessage(), e);
        }
    }

    public void waitForTitle(WebDriver driver, int timeout) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(timeout))
                    .until(ExpectedConditions.titleContains("cheese!")); // More specific condition
            logger.info("Title contains 'cheese!'");
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for title to contain 'cheese!': {}", e.getMessage(), e);
            throw new TimeoutException("Timeout waiting for title: " + e.getMessage(), e);
        }
    }

    public WebElement waitAndGetElement(WebDriver driver, WebElement element) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(60))
                    .until(ExpectedConditions.visibilityOf(element));
            logger.info("Element is visible: {}", element);
            return element;
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for element to be visible: {}", element, e);
            throw new TimeoutException("Timeout waiting for element: " + e.getMessage(), e);
        }
    }

    public boolean isPageLoad(WebDriver driver, String title) {
        try {
            return new WebDriverWait(driver, Duration.ofSeconds(WAIT_TIMEOUT))
                    .until(ExpectedConditions.titleContains(title));
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for page to load with title: {}", title, e);
            return false; // Or throw exception if you prefer
        }
    }

    public void waitForPageLoad(WebDriver driver) {
        new WebDriverWait(driver, Duration.ofSeconds(WAIT_TIMEOUT))
                .until(d -> ((JavascriptExecutor) d).executeScript("return document.readyState").equals("complete")); // Lambda expression
        logger.info("Page loaded.");

    }

    public void waitForElement(WebDriver driver, By objLocator) {
       try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); // Short implicit wait
            new WebDriverWait(driver, Duration.ofSeconds(1))
                    .until(ExpectedConditions.presenceOfElementLocated(objLocator));
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(200)); // Reset implicit wait (if needed)
            logger.info("Element is present: {}", objLocator);
        } catch (TimeoutException e) {
            logger.error("Timeout waiting for element to be present: {}", objLocator, e);
            throw new TimeoutException("Timeout waiting for element: " + e.getMessage(), e);
        }
    }
}