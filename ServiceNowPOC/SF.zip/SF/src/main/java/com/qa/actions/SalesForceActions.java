/**
 * 
 */
/**
 * @author t006535
 *
 */
package com.qa.actions;

import com.qa.webELEMENTS.SalesForceWebPageElements;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.qa.utils.Wait;
import com.qa.utils.GenericFunction;

public class SalesForceActions extends SalesForceWebPageElements {
	Wait wait = new Wait();

	public SalesForceActions() {
		super();
	}

	public void SignInPage(WebDriver driver) {
		this.driver = driver;
		if (!driver.getTitle().equals("Sign In Page")) {
			throw new IllegalStateException(
					"This is not Sign In Page," + " current page is: " + driver.getCurrentUrl());
		}
	}

	public void loginTOSalesForce(String usernameData, String passwordData) {
		waitForElementToVisible(userName, 10, "Waiting for element visibility");
		EnterText(userName, usernameData, "UserName");
		EnterText(passWord, passwordData, "Password");
		ClickElement(buttonLogin, "Login Button");
	}

	public void setupButton() throws AWTException, InterruptedException {
		wait.waitForPageLoad(driver);

		ClickElement(iconGearSetup, "SetUp");
		Thread.sleep(5000);
		WebElement dropdownElement = driver
				.findElement(By.xpath("//li[@role='presentation'][contains(@id, 'related_setup')]"));
		dropdownElement.click();

		wait.waitForPageLoad(driver);
		// fetch handles of all windows, there will be two, [0]- default, [1] - new
		// window
		Object[] windowHandles = driver.getWindowHandles().toArray();
		driver.switchTo().window((String) windowHandles[1]);
		String currentURL = driver.getCurrentUrl();
		if (currentURL.contains("setup")) {
			extentTest.log(Status.INFO, "Setup page.");
		}
		if (quickFindInput.isDisplayed()) {
			quickFindInput.sendKeys("Profiles");
			Thread.sleep(4000);
			extentTest.log(Status.INFO, "PlaceHolder-Input-QuickFind-ValueENTERED-Profiles");
		}

	}

	public void profiles() throws InterruptedException {
	    try {
	        ClickElement(profileQF, "QuickFind Profile.");
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(8));

	        // Wait for the first iframe (Profiles) and switch to it
	        WebElement firstIframe = wait.until(ExpectedConditions.presenceOfElementLocated(
	                By.xpath("//iframe[contains(@title, 'Profiles')]")));
	        driver.switchTo().frame(firstIframe);
	        System.out.println("Switched to first iframe: Profiles");

	        ClickElementJS(stringVariableE, "E-Rolodex");
	        

	        /*// Scroll into view
	        WebElement scrolling = wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//table//td/div/a/span[contains(text(), 'EB - Sales and Service')]")));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", scrolling);*/
	        ClickElementJS(ebSales, "EB - Sales and Service");
	        // Wait and switch to the second iframe (sessionserver)
	        //Thread.sleep(3000);
	        WebElement secondIframe = driver.findElement(By.xpath("//iframe[contains(@title, 'Profile: EB - Sales and Service ~ Salesforce - Unlimited Edition')]"));
	        //wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
	                //By.xpath("//iframe[contains(@title, 'Profile: EB - Sales and Service ~ Salesforce - Unlimited Edition')]"));
	        
	        //driver.switchTo().frame(firstIframe);
	        //wait.until(ExpectedConditions.visibilityOf(btnAssignedUsers));
	        driver.switchTo().frame(secondIframe);
	        System.out.println("Switched to second iframe: Profile:");
	        //wait.until(ExpectedConditions.visibilityOf(btnAssignedUsers));
	        

	        // Switch back to the main document before switching to the new iframe
	        //driver.switchTo().defaultContent();

	       

	        // Interact with elements inside the second iframe
	       // driver.switchTo().frame(firstIframe);
	        ClickElementJS(btnAssignedUsers, "Assigned Users.");

	    } catch (NoSuchElementException | TimeoutException e) {
	        System.err.println("Error encountered: " + e.getMessage());
	    } finally {
	        // Ensure we always switch back to the main content
	        driver.switchTo().defaultContent();
	        System.out.println("Switched back to main content.");
	    }
	}

	/*public void profiles() throws InterruptedException {
	    try {
	        ClickElement(profileQF, "QuickFind Profile.");
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

	        // Wait for iframe's parent container (Adjust selector as per actual DOM structure)
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'content iframe-parent')]")));

	        // Retry finding iframes
	        List<WebElement> iframesBefore = driver.findElements(By.tagName("iframe"));
	        if (iframesBefore.isEmpty()) {
	            throw new NoSuchElementException("No iframes found before switching.");
	        }

	        // Switch to the latest iframe
	        WebElement latestIframe = iframesBefore.get(iframesBefore.size() - 1);
	        driver.switchTo().frame(latestIframe);
	        System.out.println("Switched to first iframe");

	        ClickElementJS(stringVariableE, "E-Rolodex");

	        // Wait for "EB - Sales and Service" to be clickable and click it
	       
	        ClickElementJS(ebSales, "EB - Sales and Service");

	        // Detect iframe refresh and wait for a new iframe
	        wait.until(ExpectedConditions.stalenessOf(latestIframe));

	        // Wait for the new iframe container before searching for the iframe
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'content iframe-parent')]")));

	        // Get the refreshed iframe
	        List<WebElement> iframesAfter = driver.findElements(By.tagName("iframe"));
	        if (iframesAfter.isEmpty()) {
	            throw new NoSuchElementException("No new iframe found after refresh.");
	        }

	        WebElement newIframe = iframesAfter.get(iframesAfter.size() - 1);
	        driver.switchTo().frame(newIframe);
	        System.out.println("Switched to new iframe");

	        ClickElementJS(btnAssignedUsers, "Assigned Users.");

	    } catch (NoSuchElementException | TimeoutException e) {
	        System.err.println("Error encountered: " + e.getMessage());
	    } finally {
	        driver.switchTo().defaultContent();
	        System.out.println("Switched back to main content.");
	    }
	}
*/

}