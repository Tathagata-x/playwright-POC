package SalesForceSuite.SF_EBEN;

import com.microsoft.playwright.*;
import com.microsoft.playwright.ElementHandle.ScrollIntoViewIfNeededOptions;
import com.microsoft.playwright.options.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import java.util.*;
import java.util.regex.Pattern;

public class Example {
  public static void main(String[] args) {
    try (Playwright playwright = Playwright.create()) {
      Browser browser = playwright.firefox().launch(new BrowserType.LaunchOptions()
        .setHeadless(false));
      BrowserContext context = browser.newContext();
      Page page = context.newPage();
      page.navigate("https://oasf--stage.sandbox.my.salesforce.com/");
      page.getByLabel("Username").fill("tathagata.bhattacharyya@oneamerica.com");
      page.getByLabel("Password").fill("Nextday19");
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Log In to Sandbox")).click();
      
      page.waitForURL("https://oasf--stage.sandbox.lightning.force.com/lightning/page/home");
      assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup"))).isVisible();
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup")).click();
      Page page1 = page.waitForPopup(() -> {
        page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab Setup for current app")).click();
      });
      page1.navigate("https://oasf--stage.sandbox.my.salesforce-setup.com/lightning/setup/SetupOneHome/home");
      page1.getByPlaceholder("Quick Find").click();
      page1.getByPlaceholder("Quick Find").fill("Profiles");
      
      page1.getByPlaceholder("Quick Find").press("ArrowRight");
      //
      page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Profiles")).click();
      page1.locator("iframe[title=\"Profiles ~ Salesforce - Unlimited Edition\"]").contentFrame().getByRole(AriaRole.LINK, new FrameLocator.GetByRoleOptions().setName("E").setExact(true)).click();
      page1.locator("iframe[title=\"Profiles ~ Salesforce - Unlimited Edition\"]").contentFrame().getByRole(AriaRole.LINK, new FrameLocator.GetByRoleOptions().setName("EB - Sales and Service")).click();
      page1.locator("iframe[title=\"Profile: EB - Sales and Service ~ Salesforce - Unlimited Edition\"]").contentFrame().getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Assigned Users")).click();
      page1.locator("iframe[title=\"EB - Sales and Service ~ Salesforce - Unlimited Edition\"]").contentFrame().getByTitle("Login - Record 4 - Allen").click();
     
      page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Accounts")).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("New")).click();
      page1.locator("label").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Employer$"))).locator("span").first().click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Next")).click();
      page1.getByLabel("*Account Name+").click();
      page1.getByLabel("*Account Name+").fill("Account Name");
      page1.getByLabel("*Account Name+").press("ControlOrMeta+ArrowLeft");
      page1.getByLabel("*Account Name+").fill("AccountName");
      page1.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("EB RGO")).click();
      page1.getByTitle("Chicago").click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save").setExact(true)).click();
      page1.locator("div").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Edit AOR 4% Bonus$"))).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Edit AOR 4% Bonus")).click();
      page1.getByLabel("Opportunities").getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Show more actions")).click();
      page1.getByLabel("Policies").getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Show more actions")).click();
      assertThat(page1.getByText("Opportunities(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
      assertThat(page1.getByText("Policies(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
      assertThat(page1.getByText("Contacts(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
      assertThat(page1.getByText("Related Contacts(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
      assertThat(page1.getByText("Cases(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
      assertThat(page1.getByText("Notes(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
      /*Locator notesAttachments = page1.getByText("Notes & Attachments(0)", new Page.GetByTextOptions());
      notesAttachments.scrollIntoViewIfNeeded();

      // Assert visibility
      assertThat(notesAttachments).isVisible();*/
      assertThat(page1.getByText("PH Branch", new Page.GetByTextOptions().setExact(true))).isVisible();
      assertThat(page1.getByText("PH Main", new Page.GetByTextOptions().setExact(true))).isVisible();
      //assertThat(page1.locator("records-record-layout-item").filter(new Locator.FilterOptions().setHasText("AccountNameAccount Name+Edit")).locator("lightning-formatted-text")).isVisible();
      /*page1.getByLabel("Contacts", new Page.GetByLabelOptions().setExact(true)).getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Show more actions")).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save")).click();
      page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Accounts")).click();*/
      //assertThat(page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Contacts"))).isVisible();
      page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Contacts")).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("New")).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Next")).click();
      page1.getByLabel("*Account Name+").click();
      page1.getByLabel("*Account Name+").fill("AccempProspect");
      page1.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("EB RGO")).click();
      page1.getByTitle("Charlotte").click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save").setExact(true)).click();
      page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Contacts")).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("New")).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Next")).click();
      page1.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("Salutation")).click();
      page1.getByRole(AriaRole.OPTION, new Page.GetByRoleOptions().setName("Mr.")).locator("span").nth(1).click();
      page1.getByPlaceholder("Last Name+").click();
      page1.getByPlaceholder("Last Name+").fill("LastName");
      page1.getByPlaceholder("First Name+").click();
      page1.getByPlaceholder("First Name+").fill("FirstName");
      page1.getByText("Chase, Michael").click();
      page1.getByText("Chase, Michael").click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Move to Chosen Move selection")).click();
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save").setExact(true)).click();
      assertThat(page1.locator("div").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Producer Lead$"))).nth(2)).isVisible();
      page1.getByLabel("New Contact: Producer Lead").getByLabel("Mailing City+").click();
      page1.getByLabel("New Contact: Producer Lead").getByLabel("Mailing City+").fill("New York");
      page1.getByLabel("New Contact: Producer Lead").getByLabel("Mailing State/Province+").click();
      page1.getByLabel("New Contact: Producer Lead").getByLabel("Mailing State/Province+").fill("New York");
      page1.getByLabel("No email available").check();
      page1.getByLabel("New Contact: Producer Lead").getByText("Save", new Locator.GetByTextOptions().setExact(true)).click();
      page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Mailing State/Province+")).click();
      page1.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Mailing State/Province+")).dblclick();
      page1.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Mailing State/Province+")).fill("NY");
      page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save").setExact(true)).click();
      page1.navigate("https://oasf--stage.sandbox.lightning.force.com/lightning/r/Contact/003VF00000NBNYmYAP/view?0.source=alohaHeader");
    }
  }
  }


