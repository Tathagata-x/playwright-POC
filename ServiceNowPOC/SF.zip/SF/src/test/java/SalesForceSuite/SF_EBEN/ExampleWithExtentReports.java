package SalesForceSuite.SF_EBEN;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import java.util.regex.Pattern;

public class ExampleWithExtentReports {
    public static void main(String[] args) {
        ExtentReports extent = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("ExtentReport.html");
        extent.attachReporter(spark);

        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
            BrowserContext context = browser.newContext();
            Page mainPage = context.newPage();

            // Test Case 01: Login as System Admin
            ExtentTest test1 = executeTestCase01(extent, mainPage);
            
            // Test Case 02: Login as EB Sales and Service User
            Page setupPage = executeTestCase02(extent, mainPage);
            
            // Test Case 03: Create Employee Account
            executeTestCase03(extent, setupPage);
            
            // Test Case 04: Validations and Related Lists
            executeTestCase04(extent, setupPage);

        } catch (Exception e) {
            extent.flush();
            return;
        }
        extent.flush();
    }

    private static ExtentTest executeTestCase01(ExtentReports extent, Page page) {
        ExtentTest test = extent.createTest("Test Case 01", "Verify login as System Administrator");
        try {
            test.log(Status.INFO, "Navigating to Salesforce login page");
            page.navigate("https://oasf--stage.sandbox.my.salesforce.com/");
            
            test.log(Status.INFO, "Entering username and password");
            page.getByLabel("Username").fill("tathagata.bhattacharyya@oneamerica.com");
            page.getByLabel("Password").fill("Nextday19");
            page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Log In to Sandbox")).click();
            
            page.waitForURL("https://oasf--stage.sandbox.lightning.force.com/lightning/page/home");
            assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup"))).isVisible();
            test.pass("Successfully logged in as System Administrator");
        } catch (Exception e) {
            test.fail("Test Case 01 failed: " + e.getMessage());
            throw e;
        }
        return test;
    }

    private static Page executeTestCase02(ExtentReports extent, Page mainPage) {
        ExtentTest test = extent.createTest("Test Case 02", "Verify login as EB Sales and Service Profile user");
        try {
            test.log(Status.INFO, "Accessing Setup menu");
            mainPage.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup")).click();

            // Handle new tab properly
            Page setupPage = mainPage.waitForPopup(() -> {
                mainPage.getByRole(AriaRole.MENUITEM, 
                    new Page.GetByRoleOptions().setName("Setup Opens in a new tab Setup for current app")).click();
            });
            
            setupPage.waitForLoadState();
            setupPage.navigate("https://oasf--stage.sandbox.my.salesforce-setup.com/lightning/setup/SetupOneHome/home");
            
            test.log(Status.INFO, "Searching for Profiles");
            setupPage.getByPlaceholder("Quick Find").click();
            setupPage.getByPlaceholder("Quick Find").fill("Profiles");
            setupPage.getByPlaceholder("Quick Find").press("ArrowRight");
            
            test.log(Status.INFO, "Selecting EB Sales and Service profile");
            setupPage.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Profiles")).click();
            
            // Add proper frame handling
            FrameLocator profileFrame = setupPage.frameLocator("iframe[title=\"Profiles ~ Salesforce - Unlimited Edition\"]");
            profileFrame.getByRole(AriaRole.LINK, new FrameLocator.GetByRoleOptions().setName("E").setExact(true)).click();
            profileFrame.getByRole(AriaRole.LINK, new FrameLocator.GetByRoleOptions().setName("EB - Sales and Service")).click();
            
            FrameLocator serviceFrame = setupPage.frameLocator("iframe[title=\"Profile: EB - Sales and Service ~ Salesforce - Unlimited Edition\"]");
            serviceFrame.getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Assigned Users")).click();
            
            FrameLocator finalFrame = setupPage.frameLocator("iframe[title=\"EB - Sales and Service ~ Salesforce - Unlimited Edition\"]");
            finalFrame.getByTitle("Login - Record 4 - Allen").click();
            
            test.pass("Successfully logged in as EB Sales and Service user");
            return setupPage;
        } catch (Exception e) {
            test.fail("Test Case 02 failed: " + e.getMessage());
            throw e;
        }
    }

    private static void executeTestCase03(ExtentReports extent, Page setupPage) {
        ExtentTest test = extent.createTest("Test Case 03", "Verify user can create New Employee Account");
        try {
            test.log(Status.INFO, "Navigating to Accounts");
            setupPage.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Accounts")).click();
            
            test.log(Status.INFO, "Creating new Employer account");
            setupPage.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("New")).click();
            
            setupPage.locator("label").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Employer$"))).locator("span").first().click();
            setupPage.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Next")).click();
            
            setupPage.getByLabel("*Account Name+").click();
            setupPage.getByLabel("*Account Name+").fill("AccountName");
            
            setupPage.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("EB RGO")).click();
            setupPage.getByTitle("Chicago").click();
            
            setupPage.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save").setExact(true)).click();
            test.pass("Employee account created successfully");
        } catch (Exception e) {
            test.fail("Test Case 03 failed: " + e.getMessage());
            throw e;
        }
    }

    private static void executeTestCase04(ExtentReports extent, Page setupPage) {
        ExtentTest test = extent.createTest("Test Case 04", "Verify validations and related lists");
        try {
            test.log(Status.INFO, "Checking validations and related lists");
            setupPage.locator("div").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Edit AOR 4% Bonus$"))).click();
            setupPage.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Edit AOR 4% Bonus")).click();
            
            test.log(Status.INFO, "Validating fields");
            assertThat(setupPage.getByText("PH Branch", new Page.GetByTextOptions().setExact(true))).isVisible();
            assertThat(setupPage.getByText("PH Main", new Page.GetByTextOptions().setExact(true))).isVisible();
            
            test.log(Status.INFO, "Checking related lists");
            assertThat(setupPage.getByText("Opportunities(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
            assertThat(setupPage.getByText("Policies(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
            assertThat(setupPage.getByText("Contacts(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
            
            test.pass("Validations and related lists verified");
        } catch (Exception e) {
            test.fail("Test Case 04 failed: " + e.getMessage());
            throw e;
        }
    }
}