package tests;

import pages.LoginPage;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest extends BaseTest {

    @ParameterizedTest
    @CsvSource({
        "IVS_Testing_User, WrongPass, Demo@123"
    })
    public void testLogin(String username, String wrongPassword, String correctPassword) {
        test.info("Navigating to ServiceNow login page");
        page.navigate("https://pdsinfosysliveopsdemo2.service-now.com/");

        LoginPage loginPage = new LoginPage(page);
        test.info("Attempting login with possible incorrect credentials.");

        loginPage.loginWithRetry(username, wrongPassword, correctPassword);

        // Validate successful login
        boolean isSuccess = loginPage.isLoginSuccessful();
        if (isSuccess) {
            test.pass("Login successful.");
        } else {
            test.fail("Login failed even after retry.");
        }

        assertTrue(isSuccess, "Login assertion failed!");
    }
}
