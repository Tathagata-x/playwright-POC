package tests;

import com.microsoft.playwright.*;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import java.util.List;

import org.junit.jupiter.api.*;

public class BaseTest {
    protected static ExtentReports extent;
    protected ExtentTest test;
    protected Playwright playwright;
    protected Browser browser;
    protected BrowserContext context;
    protected Page page;

    @BeforeAll
    public static void setupReport() {
    	ExtentSparkReporter spark = new ExtentSparkReporter("test-output/ExtentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(spark);
    }

    @BeforeEach
    public void setUp(TestInfo testInfo) {
        test = extent.createTest(testInfo.getDisplayName());
        playwright = Playwright.create();
     // Launch browser with maximized window
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
            .setHeadless(false)
            .setArgs(List.of("--start-maximized")));
        // Create a browser context with no viewport (maximizes window)
        context = browser.newContext(new Browser.NewContextOptions().setViewportSize(null));        
        page = context.newPage();
    }

    @AfterEach
    public void tearDown() {
        browser.close();
        playwright.close();
        extent.flush();
    }
}
