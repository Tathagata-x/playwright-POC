package com.qa.webELEMENTS;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.utils.GenericFunction;
/**
 * Hello world!
 *
 */
public class SalesForceWebPageElements extends GenericFunction {
	public SalesForceWebPageElements() {
		super();
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(xpath = "//div[contains(@id, 'idcard')]/ancestor::div//input[@id='username']") public WebElement userName;
	@FindBy(xpath = "//div[contains(@id, 'idcard')]/ancestor::div//input[@id='password']") public WebElement passWord;
	@FindBy(xpath = "//div[contains(@id, 'idcard')]/ancestor::div//input[@id='Login']") public WebElement buttonLogin;
	@FindBy(xpath = "//div[contains(@class, 'setupGear')]/div[@class = 'uiMenu']") public WebElement iconGearSetup;
	
	
	
	@FindBy(xpath = "//input[contains(@placeholder, 'Quick Find')]") public WebElement quickFindInput;
	

	//@FindBy(xpath = "//li[@role='presentation'][contains(@id, 'related_setup')]") public WebElement dropdownElement;
	
	@FindBy(xpath = "//a[contains(@href, '/EnhancedProfiles/home')]") public WebElement profileQF;
	@FindBy(xpath = "//table//td/div/a/span[contains(text(), 'EB - Sales and Service')]") public WebElement ebSales;
	
	@FindBy(xpath = "//input[@value = 'Assigned Users']") public WebElement btnAssignedUsers;
	

	@FindBy(xpath = "//span[normalize-space()='E']") public WebElement stringVariableE;
	/*
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;

	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
	@FindBy(xpath = "") public WebElement ;
*/}
