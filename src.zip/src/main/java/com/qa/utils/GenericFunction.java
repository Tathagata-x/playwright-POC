package com.qa.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.ElementClickInterceptedException;
import org.slf4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.qa.base.TestBase;

public class GenericFunction extends TestBase {
	private static final int DEFAULT_TIMEOUT_SECONDS = 30;

	Wait wait = new Wait();

	public GenericFunction() {
		super();
	}

	// ------------------------------------------------------------------------------------
	// ---------------------- OneAmerica Reusable Library Starts Here
	// ------------------------------------------------------------------------------------

	public void ComboSelectValue(WebElement element, String strValue, String strdesc) {
		try {
			Select select = new Select(element);
			if (!strValue.isEmpty()) {

				select.selectByValue(strValue);
				System.out.println("Select Value " + "'" + strValue + "' is selected in " + strdesc);
				extentTest.log(Status.PASS, strValue + " is selected in " + strdesc);
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			extentTest.log(Status.FAIL, strValue + " is not selected in " + strdesc);
			System.out.println("Select Value :" + strValue + " is not selected in " + strdesc);
		} catch (Exception e1) {
			System.out.println("Select Value : Exception" + strValue + " Throws error " + e1.getStackTrace());
			extentTest.log(Status.FAIL, strValue + " is not selected in " + strdesc);
		}

	}

	public void ComboSelectVisibleText(WebElement element, String strValue, String strdesc) {
		try {
			Select select = new Select(element);
			if (!strValue.isEmpty()) {

				select.selectByVisibleText(strValue);
				System.out.println("Select Value " + "'" + strValue + "' is selected in " + strdesc);
				extentTest.log(Status.PASS, strValue + " is selected in " + strdesc);

			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			extentTest.log(Status.FAIL, strValue + " is not selected in " + strdesc);
			System.out.println("Select Value :" + strValue + " is not selected in " + strdesc);
		} catch (Exception e1) {
			System.out.println("Select Value : Exception" + strValue + " Throws error " + e1.getStackTrace());
			extentTest.log(Status.FAIL, strValue + " is not selected in " + strdesc);
		}

	}

	public void EnterText(WebElement element, String strValue, String strdesc) {
		try {
			// Check if strValue is null or blank (null, empty, or only spaces)
			if (StringUtils.isNotBlank(strValue)) {
				strValue = strValue.trim(); // Remove leading and trailing spaces
				element.clear(); // Clear any existing value
				element.sendKeys(strValue); // Enter the new value
				extentTest.log(Status.PASS, "'" + strValue + "' is entered to " + strdesc);
				System.out.println("EnterText: '" + strValue + "' is entered in " + strdesc);
			} else {
				// If strValue is null, empty, or just whitespace, log a failure
				extentTest.log(Status.FAIL, "No value provided for " + strdesc + " (value is either null or empty)");
				System.out.println("EnterText: No value provided for '" + strdesc + "', default value is set.");
			}
		} catch (Exception e) {
			// Handle any exceptions that occur during the operation
			e.printStackTrace();
			String errorMessage = e.getMessage() != null ? e.getMessage() : "Unknown error";
			extentTest.log(Status.FAIL, "Exception occurred while entering text to " + strdesc + ": " + errorMessage);
			System.out.println("EnterText: Exception Message: " + errorMessage + ". " + strValue
					+ " was not entered in " + strdesc);
		}
	}

	public void EnterPassword(WebElement element, String strValue, String strdesc) {
		try {

			if (!strValue.isEmpty()) {
				strValue = strValue.trim();
				element.clear();
				element.sendKeys(strValue);
				extentTest.log(Status.PASS, "********" + " is entered to " + strdesc);
				System.out.println("EnterText " + "'" + strValue + "'  is entered in  " + strdesc);
			} else {
				extentTest.log(Status.FAIL, strdesc + " is empty ");
				System.out.println(
						"EnterText " + "'" + element.getAttribute("value") + "'" + " by default is set in '" + strdesc);
			}

		} catch (Exception e) {
			e.printStackTrace();
			extentTest.log(Status.FAIL, "********" + " is not entered to " + strdesc);
			System.out.println("EnterText:Exception Message : " + e.getLocalizedMessage() + "*********"
					+ "  is not entered in  " + strdesc);
		}
	}

	public void EnterValue(WebElement element, String intValue, String strdesc) {
		try {

			if (!intValue.isEmpty()) {
				intValue = intValue.trim();
				element.clear();
				element.sendKeys(intValue);
				extentTest.log(Status.PASS, intValue + " is entered to " + strdesc);
			}

			else {
				extentTest.log(Status.FAIL, intValue + " is not empty ");
			}

		} catch (Exception e) {
			e.printStackTrace();
			extentTest.log(Status.PASS, intValue + " is not entered to " + strdesc);

		}
	}

	public void getSelectedComboValue(WebElement element, String strValue) {

		Select select = new Select(element);
		WebElement selectedvalue = select.getFirstSelectedOption();

		if (selectedvalue.getText().contains(strValue)) {
			System.out.println("DropDown: " + strValue + "  is selected ");

		} else {
			System.out.println("DropDown: " + strValue + "  is not selected ");
		}

	}

	public void ClickElement(WebElement element, String strButtonName) {
		try {
			// Try to click the element directly
			if (element.isDisplayed()) {
				element.click();
				System.out.println(strButtonName + " is clicked");
				extentTest.log(Status.PASS, strButtonName + " is clicked");
			} else {
				// If element is not visible, scroll into view and retry
				System.out.println(strButtonName + " is not visible. Trying to scroll to element and click again.");
				ScrollTo(element, "Scroll to " + strButtonName); // This should scroll the element into view
				if (element.isDisplayed()) {
					element.click();
					System.out.println(strButtonName + " is clicked after scrolling");
					extentTest.log(Status.PASS, strButtonName + " is clicked after scrolling");
				} else {
					System.out.println("Element still not visible after scrolling. Unable to click " + strButtonName);
					extentTest.fail(strButtonName + " is not visible and clickable after scrolling.");
					Assert.assertTrue(false);
				}
			}
		} catch (Exception e) {
			// Handle any other exceptions that might occur (e.g., stale element, no
			// clickability)
			System.out.println("Unable to perform click using ClickElement method for " + strButtonName
					+ ". Trying ClickElementJS method.");
			ClickElementJS(element, strButtonName); // Fallback to clicking with JavaScript if normal click fails
		}
	}

	public void ClickElementJS(WebElement element, String strButtonName) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // You can adjust the timeout value
																					// here
			// 1. Wait for the element to be clickable (most important check)
			wait.until(ExpectedConditions.elementToBeClickable(element));

			// 2. Scroll into view (still helpful, but not a guarantee)
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);

			// 3. JavaScript click
			jse.executeScript("arguments[0].click();", element);

			extentTest.pass(strButtonName + " clicked successfully (JS).");

		} catch (ElementClickInterceptedException e) {
			extentTest.fail("Click intercepted for " + strButtonName + ": " + e.getMessage());
			softAssert.fail("Click intercepted: " + strButtonName); // Use softAssert
		} catch (StaleElementReferenceException e) {
			extentTest.fail("Stale element reference for " + strButtonName + ": " + e.getMessage());
			softAssert.fail("Stale element: " + strButtonName);
		} catch (TimeoutException e) { // Catch timeout from WebDriverWait
			extentTest.fail("Timeout waiting for " + strButtonName + " to be clickable: " + e.getMessage());
			softAssert.fail("Timeout: " + strButtonName + " not clickable");
		} catch (WebDriverException e) { // Catch WebDriver exceptions
			extentTest.fail("WebDriver exception clicking " + strButtonName + ": " + e.getMessage());
			softAssert.fail("WebDriver Exception: " + strButtonName);
		} catch (Exception e) { // Catch other exceptions (be as specific as possible)
			extentTest.fail("Unexpected error clicking " + strButtonName + ": " + e.getMessage());
			softAssert.fail("Unexpected error clicking: " + strButtonName);
		}
	}

	// Taking the screenshots in base64 type
	public String takeFailureScreenShot() {
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
	}

	public boolean assertElementDisplayed(WebElement element, String elementName) {
		try {
			if (element.isDisplayed()) {
				extentTest.log(Status.PASS, elementName + " is displayed");
				return true;
			} else {
				extentTest.log(Status.FAIL, elementName + " is not displayed");
				softAssert.assertTrue(false, "Assert Element Displayed");
				return false;
			}
		} catch (Exception e) {
			try {
				e.printStackTrace();
				extentTest.fail(elementName + " is not displayed ",
						MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
			} catch (IOException e1) {
				extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
			}
			softAssert.assertTrue(false, "Assert Element Displayed");
		}
		return false;
	}

	public boolean assertElementfornonDisplayed(WebElement element, String elementName) {
		boolean flag = false;
		try {

			if (element.isDisplayed()) {
				extentTest.log(Status.PASS, elementName + " is displayed");
				flag = true;
			}

		} catch (Exception e) {

		}
		return flag;
	}

	public boolean assertElementNotDisplayed(WebElement element, String elementName) {
		boolean flag = false;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		try {
			if (element.isDisplayed()) {
				captureFailureLogWithScreenshot(elementName + " is displayed", "ElementNotDisplayed");
			} else { // Element present in the DOM but not displayed
				extentTest.pass(elementName + " is NOT displayed");
				flag = true;
			}
		} catch (NoSuchElementException e) {
			extentTest.pass(elementName + " is NOT displayed");
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
			captureFailureLogWithScreenshot(
					"Exception while checking if the element \"" + elementName + "\" is not displayed",
					"ElementNotDisplayed");
			extentTest.fail(e.getLocalizedMessage());
		}
		driver.manage().timeouts().implicitlyWait(TestUtils.IMPLICIT_WAIT, TimeUnit.SECONDS);
		return flag;
	}

	public void assertElementSelected(WebElement element, String elementName) {
		try {
			if (element.isSelected()) {
				extentTest.log(Status.PASS, elementName + " is selected");
			} else {
				extentTest.log(Status.FAIL, elementName + " is not selected");
			}
		} catch (NoSuchElementException e) {
			extentTest.log(Status.FAIL, elementName + " is not selected");
		}
	}

	public boolean assertText(WebElement element, String expectedText, String elementName) {
		try {
			if (element.getText().equalsIgnoreCase(expectedText)) {
				extentTest.log(Status.PASS, elementName + "'s text is <b>" + expectedText + "</b> as expected");
				return true;
			} else {
				try {
					extentTest.fail(
							elementName + "'s text is <b>" + element.getText() + "</b> but should be <b>" + expectedText
									+ "</b>",
							MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
				} catch (IOException e1) {
					extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
				}
				softAssert.assertTrue(false, "Assert text failed");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				e.printStackTrace();
				extentTest.fail(elementName + "'s Text is not displayed/not matched ",
						MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
			} catch (IOException e1) {
				extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
			}
			softAssert.assertTrue(false, "Assert text failed");
			return false;
		}
	}

	// Convert Amount value to String
	public boolean assertValue(WebElement element, String expectedValue, String elementName) {
		int Amnt = (int) Double.parseDouble(element.getText().replaceAll("[$,]", "").toString());
		String rawAmnt = Integer.toString(Amnt);
		System.out.println("Loan Amount:" + rawAmnt);
		try {
			if (rawAmnt.equalsIgnoreCase(expectedValue)) {
				extentTest.log(Status.PASS, elementName + "'s Value is '" + expectedValue + "' as expected");
				return true;
			} else {
				try {
					extentTest.fail(
							elementName + "'s Value is " + expectedValue + " but should be " + element.getText(),
							MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
				} catch (IOException e1) {
					extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
				}
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				e.printStackTrace();
				extentTest.fail(elementName + "'s Value is not displayed/not matched ",
						MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
			} catch (IOException e1) {
				extentTest.log(Status.FAIL, "Cannot attach the Screenshot");
			}
			return false;
		}
	}

	public boolean isEnabledElement(WebElement element) {
		try {
			if (element.isEnabled()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isDisplayedElement(WebElement element) {
		try {
			if (element.isDisplayed()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	public void ScrollTo(WebElement finalXpath2, String elementName) {
		try {
			// Initialize JavascriptExecutor
			JavascriptExecutor jse = (JavascriptExecutor) driver;

			// Scroll to the element using JavaScript
			jse.executeScript("arguments[0].scrollIntoView(true);", finalXpath2);

			// Log the successful scrolling action
			extentTest.log(Status.PASS, "Scrolled to the " + elementName + " successfully.");

		} catch (WebDriverException e) {
			// Catch WebDriver specific exceptions (e.g., element not interactable, etc.)
			String errorMessage = "Scroll failed: WebDriverException while scrolling to " + elementName + ". "
					+ e.getLocalizedMessage();
			System.err.println(errorMessage);
			extentTest.log(Status.FAIL, errorMessage);

		} catch (Exception e) {
			// Catch all other exceptions
			String errorMessage = "Scroll failed: An unexpected error occurred while scrolling to " + elementName + ". "
					+ e.getLocalizedMessage();
			System.err.println(errorMessage);
			extentTest.log(Status.FAIL, errorMessage);

			// Optionally, fail the test here if the scroll action is critical
			softAssert.assertTrue(false, "Scroll action failed for " + elementName);
		}
	}

	public void takeScreenshot(String testMethodName) {
		File Srcfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String dateName = new SimpleDateFormat("MM-dd-yyyy-hh-mm-ss").format(new Date());
			FileUtils.copyFile(Srcfile,
					new File(".//Screenshots//Passed Screenshots//" + testMethodName + "_" + dateName + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void takeFailedScreenshot(String screenShotName) {
		File Srcfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String dateName = new SimpleDateFormat("MM-dd-yyyy-hh-mm-ss").format(new Date());
			FileUtils.copyFile(Srcfile,
					new File(".//Screenshots//Failed Screenshots//" + screenShotName + "_" + dateName + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Switching to Windows
	public void switchToWindows(String screenShotName) {
		Iterator<String> windows = driver.getWindowHandles().iterator();
		String parentID = windows.next();
		String childId = windows.next();
		driver.switchTo().window(childId);
		takeScreenshot(screenShotName);
		driver.close();
		driver.switchTo().window(parentID);
	}

	// Read PDF Files actions
	public void readPDFFile() throws Exception {
		URL pdfUrl = new URL(driver.getCurrentUrl());
		InputStream in = pdfUrl.openStream();
		BufferedInputStream bf = new BufferedInputStream(in);
		PDDocument doc = PDDocument.load(bf);
		int numberOfPages = getPageCount(doc);
		System.out.println("The total number of pages " + numberOfPages);
		String content = new PDFTextStripper().getText(doc);
		System.out.println(content);
		doc.close();
	}

	public static int getPageCount(PDDocument doc) {
		// get the total number of pages in the pdf document
		int pageCount = doc.getNumberOfPages();
		return pageCount;

	}

	// Moving the cursor actions
	public void MoveToElement(WebElement element, String elementName) {
		Actions act = new Actions(driver);
		try {
			act.moveToElement(element).perform();
			extentTest.log(Status.PASS, elementName + " is hovered ");
		} catch (NoSuchElementException e) {
			extentTest.log(Status.FAIL, " Unable to hover on the " + elementName);
		}
	}

	// Database Connection actions for update
	public static void sqlDatabaseUpdate(String dbURL, String reqQuery) throws ClassNotFoundException {
		try {
			// Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// DriverManager.registerDriver(new
			// com.microsoft.sqlserver.jdbc.SQLServerDriver());
			Connection connect = DriverManager.getConnection(dbURL);
			if (connect != null) {
				System.out.println("Connected");
			}
			Statement sta = connect.createStatement();
			String sqlQry = reqQuery;
			sta.executeUpdate(sqlQry);
			connect.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public boolean waitForElementToVisible(WebElement element, long seconds, String strDesc) {
		try {
			// Use Duration.ofSeconds() to create a Duration object
			new WebDriverWait(driver, Duration.ofSeconds(seconds)) // Use the 'seconds' parameter
					.until(ExpectedConditions.visibilityOf(element));

			System.out.println(strDesc + " element is visible.");
			extentTest.log(Status.PASS, strDesc + " element is visible.");

			return true;
		} catch (TimeoutException e) {
			String errorMessage = "Unable to locate " + strDesc + " element within " + seconds + " seconds. "
					+ e.getMessage(); // Use getMessage()
			System.err.println(errorMessage);
			extentTest.fail(errorMessage);
			softAssert.assertTrue(false, "WaitFailed: " + strDesc + " element was not visible.");
			return false;
		} catch (StaleElementReferenceException e) {
			String errorMessage = "Element reference for " + strDesc + " is stale. " + e.getMessage(); // Use
																										// getMessage()
			System.err.println(errorMessage);
			extentTest.fail(errorMessage);
			softAssert.assertTrue(false, "Stale Element: " + strDesc + " reference is stale.");
			return false;
		} catch (Exception e) {
			String errorMessage = "An unexpected error occurred while waiting for " + strDesc + ". " + e.getMessage(); // Use
																														// getMessage()
			System.err.println(errorMessage);
			extentTest.fail(errorMessage);
			softAssert.assertTrue(false, "Unexpected error: " + strDesc);
			return false;
		}
	}

	public boolean assertUrl(String urlToVerify) {
		String currentUrl = driver.getCurrentUrl();
		if (currentUrl.contains(urlToVerify)) {
			extentTest.pass("URL Verified. Current URL: <b>" + currentUrl + "</b> contains <b>" + urlToVerify + "</b>");
			return true;
		} else {
			extentTest.fail("Assert URL Failed. Current URL: <b>" + currentUrl + "</b> doesn't contain <b>"
					+ urlToVerify + "</b>");
			softAssert.assertTrue(false, "Assert URL Failed");
			return false;
		}
	}

	public void captureFailureLogWithScreenshot(String failureMessage, String screeshotName) {
		try {
			extentTest.fail(failureMessage,
					MediaEntityBuilder.createScreenCaptureFromBase64String(TestUtils.getScreenshotAsBase64()).build());
		} catch (IOException e) {
			extentTest.fail(failureMessage + " [Cannot attach the Screenshot]");
		}
		TestUtils.takeScreenshot("FAIL_" + screeshotName);
		softAssert.assertTrue(false, failureMessage);
	}

	// This method will not capture log, use this method when required to scroll to
	// the element and take screenshot
	public void ScrollToJSNoLog(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
