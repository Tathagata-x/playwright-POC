package com.qa.utils;

import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import com.qa.base.PlaywrightTestBase;

public class evenMoreGenericFunctions extends PlaywrightTestBase {
    private final Page page;
    private final SoftAssert softAssert;

    public evenMoreGenericFunctions(Page page, SoftAssert softAssert) {
        this.page = page;
        this.softAssert = softAssert;
    }

    // ---------------------- Reusable Methods ----------------------

    public void ComboSelectValue(Locator element, String strValue, String strdesc) {
        try {
            element.selectOption(strValue);
            extentTest.log(Status.PASS, strValue + " selected in " + strdesc);
        } catch (Exception e) {
            handleError("select", strdesc, e);
        }
    }

    public void ComboSelectVisibleText(Locator element, String visibleText, String strdesc) {
        try {
            element.selectOption(visibleText);
            extentTest.log(Status.PASS, visibleText + " selected in " + strdesc);
        } catch (Exception e) {
            handleError("select", strdesc, e);
        }
    }

    public void EnterText(Locator element, String strValue, String strdesc) {
        if (StringUtils.isNotBlank(strValue)) {
            try {
                element.fill(strValue.trim());
                extentTest.log(Status.PASS, "'" + strValue + "' entered in " + strdesc);
            } catch (Exception e) {
                handleError("enter text", strdesc, e);
            }
        } else {
            extentTest.log(Status.FAIL, "No value provided for " + strdesc);
        }
    }

    public void ClickElement(Locator element, String elementName) {
        try {
            element.click(new Locator.ClickOptions().setTimeout(5000));
            extentTest.log(Status.PASS, elementName + " clicked");
        } catch (Exception e) {
            handleError("click", elementName, e);
            ClickElementJS(element, elementName);
        }
    }

    private void ClickElementJS(Locator element, String elementName) {
        try {
            element.evaluate("node => node.click()");
            extentTest.log(Status.PASS, elementName + " clicked using JavaScript");
        } catch (Exception e) {
            handleError("JavaScript click", elementName, e);
        }
    }

    public boolean assertElementDisplayed(Locator element, String elementName) {
        try {
            if (element.isVisible()) {
                extentTest.log(Status.PASS, elementName + " is visible");
                return true;
            }
            extentTest.log(Status.FAIL, elementName + " exists but not visible");
            return false;
        } catch (Exception e) {
            captureFailureLogWithScreenshot(elementName + " not found", elementName);
            return false;
        }
    }

    public String takeFailureScreenShot() {
        byte[] screenshotBytes = page.screenshot();
        return Base64.getEncoder().encodeToString(screenshotBytes);
    }

    public void ScrollTo(Locator element, String elementName) {
        try {
            element.scrollIntoViewIfNeeded();
            extentTest.log(Status.PASS, "Scrolled to " + elementName);
        } catch (Exception e) {
            handleError("scroll to", elementName, e);
        }
    }

    public void takeScreenshot(String testMethodName) {
        String timestamp = new SimpleDateFormat("MM-dd-yyyy-hh-mm-ss").format(new Date());
        page.screenshot(new Page.ScreenshotOptions()
            .setPath(Paths.get("./screenshots/" + testMethodName + "_" + timestamp + ".png")));
    }

    // ---------------------- Helper Methods ----------------------

    private void handleError(String action, String elementName, Exception e) {
        String errorMsg = "Failed to " + action + " " + elementName + ": " + e.getMessage();
        extentTest.log(Status.FAIL, errorMsg);
        captureFailureLogWithScreenshot(errorMsg, elementName);
        softAssert.fail(errorMsg);
    }

    private void captureFailureLogWithScreenshot(String message, String screenshotName) {
        try {
            extentTest.fail(message, 
                MediaEntityBuilder.createScreenCaptureFromBase64String(takeFailureScreenShot()).build());
        } catch (Exception e) {
            extentTest.fail(message + " [Screenshot unavailable]");
        }
        takeScreenshot("FAILURE_" + screenshotName);
    }

    // ---------------------- PDF & DB Methods (unchanged) ----------------------
    
    public void readPDFFile() throws Exception { /* Same PDFBox implementation */ }
    
    public static void sqlDatabaseUpdate(String dbURL, String reqQuery) { /* Same JDBC implementation */ }

    // ---------------------- Additional Converted Methods ----------------------

    public boolean waitForElementToVisible(Locator element, long seconds, String strDesc) {
        try {
            element.waitFor(new Locator.WaitForOptions()
                .setState(WaitForSelectorState.VISIBLE)
                .setTimeout(seconds * 1000)); // Convert seconds to milliseconds
            return true;
        } catch (Exception e) {
            captureFailureLogWithScreenshot("Element not visible: " + strDesc, strDesc);
            return false;
        }
    }


    public boolean assertText(Locator element, String expectedText, String elementName) {
        String actualText = element.textContent().trim();
        if (actualText.equalsIgnoreCase(expectedText.trim())) {
            extentTest.log(Status.PASS, elementName + " text matches: " + expectedText);
            return true;
        }
        captureFailureLogWithScreenshot(elementName + " text mismatch. Actual: " + actualText, elementName);
        return false;
    }
}
