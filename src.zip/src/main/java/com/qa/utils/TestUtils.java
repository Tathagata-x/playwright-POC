package com.qa.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.microsoft.playwright.Page;
import com.qa.base.PlaywrightTestBase;


public class TestUtils extends PlaywrightTestBase {
	
	public static long PAGE_LOAD_TIMEOUT = 20;
	public static long IMPLICIT_WAIT = 15;
	
	static Workbook book;
	static Sheet sheet;
	public static String TestDataSheetPath = prop.getProperty("testdata_path");
	
	public TestUtils() {
		super();
	}


	//To get the test data from excel sheet
	public static Object[][] getSFTestData(String SheetName) throws FileNotFoundException {
	    FileInputStream fis = null;
	    try {
	        // Check the file path
	        System.out.println("Test Data File Path: " + TestDataSheetPath);
	        fis = new FileInputStream(TestDataSheetPath);
	    } catch (FileNotFoundException e) {
	        throw new FileNotFoundException("Test Data file not found at path: " + TestDataSheetPath);
	    }

	    try {
	        book = WorkbookFactory.create(fis);
	    } catch (IOException e) {
	        e.printStackTrace();
	        return new Object[0][0]; // In case of error, return empty data
	    }

	    sheet = book.getSheet(SheetName);
	    if (sheet == null) {
	        throw new IllegalArgumentException("Sheet '" + SheetName + "' not found in the Excel file.");
	    }

	    Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
	    for (int i = 0; i < sheet.getLastRowNum(); i++) {
	        for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
	            if (sheet.getRow(i + 1).getCell(k) != null) {
	                data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
	            } else {
	                data[i][k] = ""; // Handle null cell by assigning empty string
	            }
	        }
	    }

	    return data;
	}


	

	protected static String testIDForScreenshot = "Test"; // Initialize a default test ID

    public static void takeScreenshot(String screenshotName) {
        String datetime = new SimpleDateFormat("MMddyyyyHHmmss").format(new Date());
        String filePath = "./Screenshots/" + testIDForScreenshot + "_" + datetime + "_" + screenshotName.replaceAll("/", "_") + ".png";

        try {
            page.screenshot(new Page.ScreenshotOptions()
                .setPath(Paths.get(filePath))
                .setFullPage(true)); // Captures the full page
            System.out.println("Screenshot saved: " + filePath);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Cannot capture the screenshot");
        }
    }

    public static String getScreenshotAsBase64() {
        try {
            byte[] screenshotBytes = page.screenshot();
            return Base64.getEncoder().encodeToString(screenshotBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

	public static String getFailedScreenshot(WebDriver driver, String screenshotname) throws IOException {
		String datename = new SimpleDateFormat("MM-dd-yyyy_HH-mm-ss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = ".//Screenshots//Failed Screenshots//" + screenshotname + "_" + datename + ".png";
		File finaldestination = new File(destination);
		// FileHandler.copy(source, finaldestination);
		FileUtils.copyFile(source, finaldestination);
		return destination;
	}

	public static String getPassedScreenshot(WebDriver driver, String screenshotname) throws IOException {
		String datename = new SimpleDateFormat("MM-dd-yyyy_HH-mm-ss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = ".//Screenshots//Passed Screenshots//" + screenshotname + "_" + datename + ".png";
		File finaldestination = new File(destination);
		// FileHandler.copy(source, finaldestination);
		FileUtils.copyFile(source, finaldestination);
		return destination;
	}

	private static Object[][] data = null;
	private static String previousSheet = "";

	public static List<String> getExpectedData(String sheetName, String testDataID) throws IOException {
		if (data == null || !previousSheet.equalsIgnoreCase(sheetName)) {
			data = TestUtils.getSFTestData(sheetName);
			previousSheet = sheetName;
		}
		List<String> expectedData = new ArrayList();
		for (int i = 0; i < data.length; i++) {
			// System.out.println(data[i][0].toString()+", "+data[i][1].toString());
			if (data[i][0].toString().equalsIgnoreCase(testDataID)) {
				expectedData.add(data[i][1].toString());
			}
		}
		return expectedData;
	}

}
