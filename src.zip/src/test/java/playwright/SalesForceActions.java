package playwright;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.WaitUntilState;

import java.util.List;

public class SalesForceActions {
    Playwright playwright;
    Browser browser;
    BrowserContext context;
    Page page;

    public SalesForceActions() {
        playwright = Playwright.create();
        browser = playwright.firefox().launch(new BrowserType.LaunchOptions().setHeadless(false));
        context = browser.newContext();
        page = context.newPage();
    }

    public void loginToSalesForce(String username, String password) {
        page.navigate("https://login.salesforce.com", new Page.NavigateOptions().setWaitUntil(WaitUntilState.LOAD));

        page.locator("//input[@id='username']").fill(username);
        page.locator("//input[@id='password']").fill(password);
        page.locator("//input[@id='Login']").click();

        page.waitForLoadState();
        System.out.println("Login successful!");
    }

    public void navigateToProfiles() {
        page.locator("//div[contains(@class, 'setupGear')]/div[@class='uiMenu']").click();
        page.waitForTimeout(3000);
        
        page.locator("//a[contains(@href, '/EnhancedProfiles/home')]").click();
        page.waitForTimeout(5000);

        // Switch to first iframe
        FrameLocator firstFrame = page.frameLocator("iframe[title*='Profiles']");
        firstFrame.locator("//span[normalize-space()='E']").click();

        firstFrame.locator("//table//td/div/a/span[contains(text(), 'EB - Sales and Service')]").click();

        // Switch to second iframe
        FrameLocator secondFrame = page.frameLocator("iframe[title*='Profile: EB - Sales and Service']");
        secondFrame.locator("//input[@value='Assigned Users']").click();

        System.out.println("Navigated to Assigned Users in Profile iframe.");
    }

    public void closeBrowser() {
        browser.close();
        playwright.close();
    }
}

