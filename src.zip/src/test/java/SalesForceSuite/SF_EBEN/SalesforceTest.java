package SalesForceSuite.SF_EBEN;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import java.util.regex.Pattern;

public class SalesforceTest {
    private static ExtentReports extent;
    private static ExtentTest test;

    public static void main(String[] args) {
        // Set up ExtentReports
        ExtentSparkReporter htmlReporter = new ExtentSparkReporter("SalesforceTestReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        test = extent.createTest("Salesforce Automation", "Verify Salesforce functionalities");

        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
            BrowserContext context = browser.newContext();
            Page page = context.newPage();
            
            test.info("Navigating to Salesforce login page");
            page.navigate("https://oasf--stage.sandbox.my.salesforce.com/");
            page.getByLabel("Username").fill("your-username");
            page.getByLabel("Password").fill("your-password");
            page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Log In to Sandbox")).click();

            page.waitForURL("https://oasf--stage.sandbox.lightning.force.com/lightning/page/home");
            test.pass("Login successful");

            assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup"))).isVisible();
            page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup")).click();

            Page page1 = page.waitForPopup(() -> {
                page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab Setup for current app")).click();
            });

            test.info("Navigated to Setup page");
            page1.navigate("https://oasf--stage.sandbox.my.salesforce-setup.com/lightning/setup/SetupOneHome/home");

            page1.getByPlaceholder("Quick Find").fill("Profiles");
            page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Profiles")).click();
            page1.locator("iframe[title=\"Profiles ~ Salesforce - Unlimited Edition\"]").contentFrame()
                .getByRole(AriaRole.LINK, new FrameLocator.GetByRoleOptions().setName("EB - Sales and Service"))
                .click();
            
            test.pass("Navigated to EB Sales and Service Profile");

            // Scroll and validate Notes & Attachments section
            Locator notesAttachments = page1.getByText("Notes & Attachments(0)", new Page.GetByTextOptions().setExact(true));
            notesAttachments.scrollIntoViewIfNeeded();
            assertThat(notesAttachments).isVisible();
            test.pass("Notes & Attachments section is visible after scrolling");

            // Additional related object validation
            assertThat(page1.getByText("Opportunities(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
            assertThat(page1.getByText("Policies(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
            assertThat(page1.getByText("Contacts(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
            test.pass("Validated related objects visibility");

        } catch (Exception e) {
            test.fail("Test failed: " + e.getMessage());
        } finally {
            extent.flush();
        }
    }
}

