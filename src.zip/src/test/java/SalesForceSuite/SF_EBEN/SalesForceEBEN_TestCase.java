package SalesForceSuite.SF_EBEN;

import java.awt.AWTException;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.actions.SalesForceActions;
import com.qa.base.TestBase;
import com.qa.utils.TestUtils;


/* ******************************************************************
> 	Test Name  : validateSalesFORCECRM
> 	Purpose    : To validate the validateSalesFORCECRM Account Activity feature 
> 	Author     : 10-FEB-2025 by TathaB
> 	***********************************************************************/

public class SalesForceEBEN_TestCase extends TestBase {
	SalesForceActions SalesForceActions;

	public SalesForceEBEN_TestCase() {
		super();
	}

	@BeforeClass
	public void setUp() {
		initialization();
		SalesForceActions = new SalesForceActions();
	}
	 @AfterMethod
	    public void tearDown(ITestResult result) throws IOException {
	        // Your tear down logic here (logging, screenshots, etc.)
	    }


	@DataProvider
	public Object[][] getSalesforceTestData() throws FileNotFoundException {
		Object data[][] = TestUtils.getSFTestData("SalesForceLoginDATA");
		return data;
	}

	@Test(dataProvider = "getSalesforceTestData")
	public void validateSalesForceAccountActivityFeature(String usernameData, String passwordData) throws InterruptedException, AWTException {
		extentTest = extent.createTest("SalesForceCRM Features and Activities.");
		SalesForceActions.loginTOSalesForce(usernameData, passwordData);
		SalesForceActions.setupButton();
		SalesForceActions.profiles();
	}
}
