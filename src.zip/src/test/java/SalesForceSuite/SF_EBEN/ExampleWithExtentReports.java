package SalesForceSuite.SF_EBEN;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import java.util.regex.Pattern;

public class ExampleWithExtentReports {
    public static void main(String[] args) {
        ExtentReports extent = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("ExtentReport.html");
        extent.attachReporter(spark);

        ExtentTest test1 = extent.createTest("Test Case 01", "Verify login as System Administrator");
        ExtentTest test2 = extent.createTest("Test Case 02", "Verify login as EB Sales and Service Profile user");
        ExtentTest test3 = extent.createTest("Test Case 03", "Verify user can create New Employee Account");
        ExtentTest test4 = extent.createTest("Test Case 04", "Verify validations and related lists");

        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
            BrowserContext context = browser.newContext();
            Page page = context.newPage();

            // Test Case 01: Login as System Admin
            try {
                test1.log(Status.INFO, "Navigating to Salesforce login page");
                page.navigate("https://oasf--stage.sandbox.my.salesforce.com/");
                test1.log(Status.INFO, "Entering username and password");
                page.getByLabel("Username").fill("pambala.prashanth@oneamerica.com.stage");
                page.getByLabel("Password").fill("Chair@1995");
                page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Log In to Sandbox")).click();
                page.waitForURL("https://oasf--stage.sandbox.lightning.force.com/lightning/page/home");
                test1.log(Status.INFO, "Checking Setup button visibility");
                assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup"))).isVisible();
                test1.pass("Successfully logged in as System Administrator");
            } catch (Exception e) {
                test1.fail("Test Case 01 failed: " + e.getMessage());
                throw e;
            }

            // Test Case 02: Login as EB Sales and Service User
            try {
                test2.log(Status.INFO, "Accessing Setup menu");
                page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Setup")).click();
                Page page1 = page.waitForPopup(() -> {
                    page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Setup Opens in a new tab Setup for current app")).click();
                });
                page1.navigate("https://oasf--stage.sandbox.my.salesforce-setup.com/lightning/setup/SetupOneHome/home");
                test2.log(Status.INFO, "Searching for Profiles");
                page1.getByPlaceholder("Quick Find").click();
                page1.getByPlaceholder("Quick Find").fill("Profiles");
                page1.getByPlaceholder("Quick Find").press("ArrowRight");
                test2.log(Status.INFO, "Selecting EB Sales and Service profile");
                page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Profiles")).click();
                page1.locator("iframe[title=\"Profiles ~ Salesforce - Unlimited Edition\"]").contentFrame().getByRole(AriaRole.LINK, new FrameLocator.GetByRoleOptions().setName("E").setExact(true)).click();
                page1.locator("iframe[title=\"Profiles ~ Salesforce - Unlimited Edition\"]").contentFrame().getByRole(AriaRole.LINK, new FrameLocator.GetByRoleOptions().setName("EB - Sales and Service")).click();
                page1.locator("iframe[title=\"Profile: EB - Sales and Service ~ Salesforce - Unlimited Edition\"]").contentFrame().getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Assigned Users")).click();
                page1.locator("iframe[title=\"EB - Sales and Service ~ Salesforce - Unlimited Edition\"]").contentFrame().getByTitle("Login - Record 4 - Allen").click();
                test2.pass("Successfully logged in as EB Sales and Service user");
            } catch (Exception e) {
                test2.fail("Test Case 02 failed: " + e.getMessage());
                throw e;
            }

            // Test Case 03: Create Employee Account
            try {
                test3.log(Status.INFO, "Navigating to Accounts");
                page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Accounts")).click();
                test3.log(Status.INFO, "Creating new Employer account");
                page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("New")).click();
                page1.locator("label").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Employer$"))).locator("span").first().click();
                page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Next")).click();
                page1.getByLabel("*Account Name+").click();
                page1.getByLabel("*Account Name+").fill("AccountName");
                page1.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("EB RGO")).click();
                page1.getByTitle("Chicago").click();
                page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save").setExact(true)).click();
                test3.pass("Employee account created successfully");
            } catch (Exception e) {
                test3.fail("Test Case 03 failed: " + e.getMessage());
                throw e;
            }

            // Test Case 04: Validations and Related Lists
            try {
                test4.log(Status.INFO, "Checking validations and related lists");
                page1.locator("div").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Edit AOR 4% Bonus$"))).click();
                page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Edit AOR 4% Bonus")).click();
                test4.log(Status.INFO, "Validating fields");
                assertThat(page1.getByText("PH Branch", new Page.GetByTextOptions().setExact(true))).isVisible();
                assertThat(page1.getByText("PH Main", new Page.GetByTextOptions().setExact(true))).isVisible();
                test4.log(Status.INFO, "Checking related lists");
                assertThat(page1.getByText("Opportunities(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
                assertThat(page1.getByText("Policies(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
                assertThat(page1.getByText("Contacts(0)", new Page.GetByTextOptions().setExact(true))).isVisible();
                test4.pass("Validations and related lists verified");
            } catch (Exception e) {
                test4.fail("Test Case 04 failed: " + e.getMessage());
                throw e;
            }

        } catch (Exception e) {
            extent.flush();
            return;
        }
        extent.flush();
    }
}