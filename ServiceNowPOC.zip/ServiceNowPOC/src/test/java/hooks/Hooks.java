package hooks;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.Tracing;
import factory.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.WebActions;

import java.nio.file.Paths;

public class Hooks {
    private DriverFactory driverFactory;
    private Page page;

    @Before
    public void launchBrowser() {
        // Initialize DriverFactory and launch the browser
        driverFactory = new DriverFactory();
        String browserName = WebActions.getProperty("browser"); // Fetch browser name from config file
        page = driverFactory.initDriver(browserName); // Start the browser and initialize the page
    }

    @After(order = 1)
    public void takeScreenshotAndTrace(Scenario scenario) {
        // Capture a screenshot and trace file on test failure
        if (scenario.isFailed()) {
            String screenshotName = scenario.getName().replaceAll(" ", "_"); // Replace spaces with underscores
            byte[] screenshotBytes = page.screenshot(); // Take a screenshot
            scenario.attach(screenshotBytes, "image/png", screenshotName); // Attach the screenshot to the report

            // Stop tracing and save the trace file
            DriverFactory.getContext().tracing().stop(
                new Tracing.StopOptions().setPath(Paths.get("target/" + screenshotName + "_trace.zip"))
            );
        }
    }

    @After(order = 0)
    public void quitBrowser() {
        // Do not close the browser context or page to allow continuity between features
        if (WebActions.getProperty("closeBrowserAfterFeature").equalsIgnoreCase("true")) {
            page.close(); // Close the current page
            DriverFactory.getContext().close(); // Close the browser context
            if (DriverFactory.getPage() != null) {
                DriverFactory.getPage().context().browser().close(); // Close the browser if needed
            }
        }
    }
}
