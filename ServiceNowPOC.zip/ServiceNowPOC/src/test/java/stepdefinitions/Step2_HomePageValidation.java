package stepdefinitions;

import org.junit.Assert;

import factory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageElements;

public class Step2_HomePageValidation {
	HomePageElements HomePageElements = new HomePageElements(DriverFactory.getPage());

	
	@Given("the user is on the home page")
	public void the_user_is_on_the_home_page() {

		Assert.assertTrue(HomePageElements.verifyHeaderDisplay());
		//HomePageElements.home_plus_button();
	}
	
	@When("the user clicks on the {string} button in the navigation panel")
	public void the_user_clicks_on_the_button_in_the_navigation_panel(String string) {
	    // Write code here that turns the phrase above into concrete actions
		HomePageElements.menuItemClick();
	}

	@And("the user types {string} in the search box")
	public void the_user_types_in_the_search_box(String string) {
	    // Write code here that turns the phrase above into concrete actions
		HomePageElements.filterMenuItem();
	    throw new io.cucumber.java.PendingException();
	}

	@Then("the {string} subcategory should load")
	public void the_subcategory_should_load(String string) {
	    // Write code here that turns the phrase above into concrete actions
		HomePageElements.filterSubCategory();
	    throw new io.cucumber.java.PendingException();
	}

	@When("the user clicks on the {string} link under the {string} subcategory")
	public void the_user_clicks_on_the_link_under_the_subcategory(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		HomePageElements.clickOnSubCategory();
	    throw new io.cucumber.java.PendingException();
	}

	@Then("the user should be taken to the Create New page")
	public void the_user_should_be_taken_to_the_create_new_page() {
	    // Write code here that turns the phrase above into concrete actions
		HomePageElements.awaitingChgReqPage();
	    throw new io.cucumber.java.PendingException();
	}
	
}
