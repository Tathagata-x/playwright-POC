package stepdefinitions;

import factory.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import pages.LoginPageSerivceNow;


public class Step1_LoginSteps {
	LoginPageSerivceNow LoginPageSerivceNow = new LoginPageSerivceNow(DriverFactory.getPage());

    @Given("^user navigates to \"([^\"]*)\"$")
    public void navigateToUrl(String url) {
    	LoginPageSerivceNow.navigateToUrl(url);
    }

    @When("^user enters \"([^\"]*)\" username$")
    public void enterUsername(String username) {
    	LoginPageSerivceNow.enterUsername(username);
    }

    @When("^user enters \"([^\"]*)\" password$")
    public void enterPassword(String password) {
    	LoginPageSerivceNow.enterPassword(password);
    }

    @When("^user clicks Login button$")
    public void clickLogin() {
    	LoginPageSerivceNow.clickLogin();
    }
	
	  @Then("verify that user is logged in and navigated to Profile page") 
	  public void verifyProfilePage() { 
		  Assert.assertTrue(LoginPageSerivceNow.verifyProfilePage());
	  }

}
