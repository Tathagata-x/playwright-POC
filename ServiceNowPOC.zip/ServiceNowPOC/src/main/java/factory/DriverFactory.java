package factory;

import com.microsoft.playwright.*;
import utils.WebActions;

public class DriverFactory {
    private Browser browser;
    private static BrowserContext context;
    private static Page page;

    private static ThreadLocal<Page> threadLocalDriver = new ThreadLocal<>(); // For Parallel Execution
    private static ThreadLocal<BrowserContext> threadLocalContext = new ThreadLocal<>();

    // Launches Browser as set by user in config file
    public Page initDriver(String browserName) {
        BrowserType browserType = null;
        boolean headless = Boolean.parseBoolean(WebActions.getProperty("headless"));

        // Launch Browser based on the configuration
        switch (browserName.toLowerCase()) {
            case "firefox":
                browserType = Playwright.create().firefox();
                browser = browserType.launch(new BrowserType.LaunchOptions().setHeadless(headless));
                break;
            case "chrome":
                browserType = Playwright.create().chromium();
                browser = browserType.launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(headless));
                break;
            case "webkit":
                browserType = Playwright.create().webkit();
                browser = browserType.launch(new BrowserType.LaunchOptions().setHeadless(headless));
                break;
            default:
                throw new IllegalArgumentException("Unsupported browser: " + browserName);
        }

        // Reuse existing context if already initialized
        if (context == null) {
            context = browser.newContext(); // Create a new context
            // Enable tracing for debugging purposes
            context.tracing().start(new Tracing.StartOptions().setScreenshots(true).setSnapshots(true).setSources(false));
        }

        // Reuse or create a new page
        if (page == null) {
            page = context.newPage();
        }

        // Store the context and page in ThreadLocal for parallel execution
        threadLocalDriver.set(page);
        threadLocalContext.set(context);

        return page;
    }

    public static synchronized Page getPage() {
        return threadLocalDriver.get(); // Return the initialized ThreadLocal page
    }

    public static synchronized BrowserContext getContext() {
        return threadLocalContext.get(); // Return the initialized ThreadLocal context
    }

    public void closeDriver() {
        // Stop tracing and close context
        if (context != null) {
            context.tracing().stop(); // Optional: Save the trace file for debugging
            context.close();
        }
        // Close the browser
        if (browser != null) {
            browser.close();
        }
        threadLocalDriver.remove();
        threadLocalContext.remove();
    }
}
