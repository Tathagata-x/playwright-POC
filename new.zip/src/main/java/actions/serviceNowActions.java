package actions;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.*;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.testng.asserts.SoftAssert;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import com.qa.base.PlaywrightTestBase;
import com.qa.utils.CommonPlaywrightActions;


/**
 * ServiceNowActions captures all common actions used in ServiceNow flows.
 * It imports generic functions (navigate, click, fill, press, etc.) from CommonPlaywrightActions that
 * wrap Playwright API calls and log the actions using ExtentReports.
 * These functions abstract the underlying interactions (including error handling)
 * so that your test scripts can focus on the test flow.
 */
public class serviceNowActions extends PlaywrightTestBase {

    private final Page page;
    private final SoftAssert softAssert;
    private final CommonPlaywrightActions utils;

    public serviceNowActions(Page page, SoftAssert softAssert, ExtentTest extentTest) {
        this.page = page;
        this.softAssert = softAssert;
        this.extentTest = extentTest;
        // Pass the ExtentTest instance to the utility class
        this.utils = new CommonPlaywrightActions(page, softAssert, extentTest);
    }


    // --------------------- Navigation ---------------------

    /**
     * Navigates the browser to the specified URL.
     * @param url The URL to navigate to.
     */
    public void navigateToURL(String url) {
        try {
            page.navigate(url);
            extentTest.log(Status.PASS, "Navigated to URL: " + url);
        } catch(Exception e) {
            utils.handleError("navigate", "URL: " + url, e);
        }
    }

    // --------------------- Click Actions ---------------------

    /**
     * Clicks an element located by its label.
     * @param label The accessible label of the element.
     * @param exact If true, uses an exact match.
     */
    public void clickElementByLabel(String label, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            utils.ClickElement(locator, label);
        } catch(Exception e) {
            utils.handleError("click by label", label, e);
        }
    }
    /**
     * Clicks an element identified by its role and name.
     * @param role The ARIA role (e.g. BUTTON, MENUITEM).
     * @param name The accessible name.
     */
    public void clickElementByText(String text, boolean exact) {
        try {
            // Locate the element by its text
            Locator locator = page.getByText(text, new Page.GetByTextOptions().setExact(exact));
            // Use your generic click method to handle logging and error capture
            utils.ClickElement(locator, text);
        } catch (Exception e) {
            utils.handleError("click by text", text, e);
        }
    }


    /**
     * Clicks an element identified by its role and name.
     * @param role The ARIA role (e.g. BUTTON, MENUITEM).
     * @param name The accessible name.
     */
    public void clickElementByRole(String role, String name) {
        try {
            Locator locator = page.getByRole(AriaRole.valueOf(role.toUpperCase()), new Page.GetByRoleOptions().setName(name));
            utils.ClickElement(locator, name);
        } catch(Exception e) {
            utils.handleError("click by role", name, e);
        }
    }

    /**
     * Double clicks an element identified by its label.
     * @param label The label of the element.
     * @param exact If true, uses an exact match.
     */
    public void doubleClickElementByLabel(String label, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            locator.dblclick();
            extentTest.log(Status.PASS, "Double clicked on element with label: " + label);
        } catch(Exception e) {
            utils.handleError("double click", label, e);
        }
    }

    // --------------------- Fill / Text Entry ---------------------

    /**
     * Fills an input element identified by its label with the specified text.
     * @param label The label of the input field.
     * @param text The text to fill.
     * @param exact If true, uses an exact label match.
     */
    public void fillTextByLabel(String label, String text, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            utils.EnterText(locator, text, label);
        } catch(Exception e) {
            utils.handleError("fill text by label", label, e);
        }
    }

    /**
     * Fills an input element identified by its placeholder attribute.
     * @param placeholder The placeholder text of the element.
     * @param text The text to fill.
     */
    public void fillTextByPlaceholder(String placeholder, String text) {
        try {
            Locator locator = page.getByPlaceholder(placeholder);
            utils.EnterText(locator, text, placeholder);
        } catch(Exception e) {
            utils.handleError("fill text by placeholder", placeholder, e);
        }
    }

    // --------------------- Key Press Actions ---------------------

    /**
     * Presses a key on an element identified by its label.
     * @param label The label of the element.
     * @param key The key to press (e.g. "Tab", "Enter").
     * @param exact If true, uses an exact label match.
     */
    public void pressKeyByLabel(String label, String key, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            locator.press(key);
            extentTest.log(Status.PASS, "Pressed key '" + key + "' on element with label: " + label);
        } catch(Exception e) {
            utils.handleError("press key", label, e);
        }
    }

    // --------------------- Iframe Actions ---------------------

    /**
     * Clicks an element within a specified iframe.
     * @param iframeSelector The selector for the iframe.
     * @param action In-frame locator action to be performed.
     * @param description A description of the element/action.
     */
    public void clickElementInIframe(String iframeSelector, Locator action, String description) {
        try {
            // Use a FrameLocator to interact with the element inside the iframe.
            FrameLocator frame = page.frameLocator(iframeSelector);
            // The passed Locator 'action' should be obtained via the frame locator.
            utils.ClickElement(action, description);
        } catch(Exception e) {
            utils.handleError("click in iframe", description, e);
        }
    }

    // --------------------- Popup Actions ---------------------

    /**
     * Waits for a popup to appear when triggering an action, then returns the popup Page.
     * @param popupTriggerDescription A description of what triggers the popup.
     * @param actionToTriggerPopup A Runnable that triggers the popup.
     * @return The popup Page, or null if not found.
     */
    public Page waitForPopupAndClick(String popupTriggerDescription, Runnable actionToTriggerPopup) {
        try {
            Page popup = page.waitForPopup(() -> {
                actionToTriggerPopup.run();
            });
            extentTest.log(Status.PASS, "Popup appeared after: " + popupTriggerDescription);
            return popup;
        } catch(Exception e) {
            utils.handleError("wait for popup", popupTriggerDescription, e);
            return null;
        }
    }

    // --------------------- Navigation Helpers ---------------------

    /**
     * Navigates back in browser history.
     */
    public void navigateBack() {
        try {
            page.goBack();
            extentTest.log(Status.PASS, "Navigated back");
        } catch(Exception e) {
            utils.handleError("navigate back", "Back navigation", e);
        }
    }

    /**
     * Navigates forward in browser history.
     */
    public void navigateForward() {
        try {
            page.goForward();
            extentTest.log(Status.PASS, "Navigated forward");
        } catch(Exception e) {
            utils.handleError("navigate forward", "Forward navigation", e);
        }
    }

    // --------------------- Scrolling ---------------------

    /**
     * Scrolls into view for an element identified by its label.
     * @param label The label of the element.
     * @param exact If true, uses an exact label match.
     */
    public void scrollToElementByLabel(String label, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            utils.ScrollTo(locator, label);
        } catch(Exception e) {
            utils.handleError("scroll to element", label, e);
        }
    }

    // --------------------- Combo Box / Dropdown Actions ---------------------

    /**
     * Selects a value from a combo box (dropdown) by visible text.
     * @param label The label of the combo box.
     * @param visibleText The visible text of the option to select.
     * @param exact If true, uses an exact label match.
     */
    public void selectComboByVisibleText(String label, String visibleText, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            utils.ComboSelectVisibleText(locator, visibleText, label);
        } catch(Exception e) {
            utils.handleError("select combo", label, e);
        }
    }

    // --------------------- Assertions ---------------------

    /**
     * Verifies that an element identified by its label is visible.
     * @param label The label of the element.
     * @param exact If true, uses an exact label match.
     * @return True if the element is visible, false otherwise.
     */
    public boolean verifyElementDisplayedByLabel(String label, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            return utils.assertElementDisplayed(locator, label);
        } catch(Exception e) {
            utils.handleError("verify element displayed", label, e);
            return false;
        }
    }

    /**
     * Asserts that the text content of an element (identified by its label) matches the expected text.
     * @param label The label of the element.
     * @param expectedText The expected text.
     * @param exact If true, uses an exact label match.
     * @return True if the text matches, false otherwise.
     */
    public boolean assertTextByLabel(String label, String expectedText, boolean exact) {
        try {
            Locator locator;
            if (exact) {
                locator = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
            } else {
                locator = page.getByLabel(label);
            }
            return utils.assertText(locator, expectedText, label);
        } catch(Exception e) {
            utils.handleError("assert text by label", label, e);
            return false;
        }
    }
    
    // --------------------- Additional Actions ---------------------
    
    // More functions can be added as needed (e.g., handling alerts, right-click actions, etc.)
}
