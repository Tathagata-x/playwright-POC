package pages;

import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.*;

import com.microsoft.playwright.options.*;
import com.qa.utils.CommonPlaywrightActions;


import actions.serviceNowActions;

import java.util.Properties;
import java.util.regex.Pattern;

import org.testng.asserts.SoftAssert;

/**
 * Page Object for the Example page.
 * 
 * This class defines locators for nearly every element found in Example.java,
 * including those inside the "gsft_main" iframe. Use these fields in your tests 
 * to interact with the elements without having action methods inside this class.
 */
public class ExamplePage {
	
    private final Page page;
    private final CommonPlaywrightActions utils;
    private final serviceNowActions snActions; 
    // FrameLocator for elements within the gsft_main iframe.
    private final FrameLocator gsftMainFrame;
    private final Properties prop;

    // -------------------- Main Page Locators --------------------
    // Main page body – used to establish focus.
    public final Locator bodyLocator;
    
    // Login section:
    // "User name" input field.
    public final Locator userNameInput;
    // "Password" input field (exact match).
    public final Locator passwordInput;
    // Primary "Log in" button (using role).
    public final Locator loginButton;
    // Alternate login button using a generic button locator filtered by text.
    public final Locator loginButtonAlt;

    // Landing page and navigation elements:
    // "My ServiceNow landing page" element.
    public final Locator landingPageLocator;
    // "All" label – used for filtering or selection.
    public final Locator allLocator;
    // Filter input field with placeholder "Filter".
    public final Locator filterInput;
    
    // Menu and selectors:
    // "Menu" button (exact match).
    public final Locator menuLocator;
    // "Scope selectors" element.
    public final Locator scopeSelectorsLocator;
    // "Update set: Default 1 [Global]" button.
    public final Locator updateSetButton;
    // Button indicating "IVS Testing_User: available".
    public final Locator userAvailabilityButton;
    // "Close dialog" button.
    public final Locator closeDialogButton;

    // Preferences and user selection:
    // "Preferences" menu item.
    public final Locator preferencesMenuItem;
    // "Preferences" element (exact match).
    public final Locator preferencesLocator;
    // "Select a user" field.
    public final Locator selectUserLocator;
    // Combobox for selecting a user.
    public final Locator selectUserComboBox;
    // Option for "Bernard Laboy Bernard bernard".
    public final Locator bernardOption;
    // Radio button for "Bernard Bernard Bernard".
    public final Locator bernardRadioButton;
    // "Impersonate user" menu item.
    public final Locator impersonateUserMenuItem;
    // "Impersonate user" button.
    public final Locator impersonateUserButton;

    // Dashboard and logout:
    // "My Team dashboard" heading.
    public final Locator myTeamDashboardHeading;
    // "Change dashboard" control.
    public final Locator changeDashboardLocator;
    // "Refresh dashboard" control.
    public final Locator refreshDashboardLocator;
    // "Log out" menu item.
    public final Locator logoutMenuItem;
    // "My Approvals 1 of" label.
    public final Locator myApprovalsLocator;

    // Error and informational messages:
    // Error message: "User name or password invalid".
    public final Locator invalidCredentialsMessage;
    // Welcome message on Admin Home.
    public final Locator welcomeAdminHomeMessage;
    
    // "Create New 1 of" control – starts record creation.
    public final Locator createNewRecordLocator;

    // Alternate locators:
    // Generic "Close dialog" button (if needed elsewhere).
    // (Already defined above as closeDialogButton)
    
    // Alternate locator for zoom button in popup (note: usually in a separate popup page).
    public final Locator zoomModemButton;

    // Generic locators using filtering by text:
    // Third occurrence of a div with text "ServiceNow".
    public final Locator thirdServiceNowDiv;
    // Span element with text "ServiceNow" – used for verification.
    public final Locator serviceNowSpan;

    // -------------------- Locators within the gsft_main iframe --------------------
    // "About ServiceNow" heading inside the iframe.
    public final Locator aboutServiceNowHeading;
    // "Using ServiceNow" heading inside the iframe.
    public final Locator usingServiceNowHeading;
    // "EmergencySVG/thumbtack-fill-" icon/button – emergency indicator.
    public final Locator emergencyIcon;
    // "Look up value for field: Configuration item" locator.
    public final Locator configItemLookup;
    // "Short description" field.
    public final Locator shortDescriptionField;
    // "Justification" field.
    public final Locator justificationField;
    // "Implementation plan" field.
    public final Locator implementationPlanField;
    // "Risk and impact analysis" field.
    public final Locator riskImpactAnalysisField;
    // "Backout plan" field.
    public final Locator backoutPlanField;
    // "Test plan" field.
    public final Locator testPlanField;
    // "Section Tab Lists" -> "Schedule" tab.
    public final Locator scheduleTab;
    // Button to select planned start date.
    public final Locator selectPlannedStartDateButton;
    // Date element "Saturday, March 8,".
    public final Locator saturdayMarch8Date;
    // "Time: Hour" field.
    public final Locator timeHourField;
    // "Save (Enter)" button.
    public final Locator saveEnterButton;
    // Button to select planned end date.
    public final Locator selectPlannedEndDateButton;
    // Date element "Monday, March 10,".
    public final Locator mondayMarch10Date;
    // "additional actions menu" element.
    public final Locator additionalActionsMenu;
    // "Save" menu item within the additional actions menu.
    public final Locator saveMenuItem;
    // In the Change Request form section: "Type" field.
    public final Locator changeRequestTypeField;
    // In the Change Request form section: "State" field.
    public final Locator changeRequestStateField;
    // Locator for state model request CAB approval (by CSS id).
    public final Locator stateModelRequestCabApproval;
    // Mandatory text message element.
    public final Locator mandatoryTextMessage;
    // "Look up value for field: Assignment group" locator.
    public final Locator assignmentGroupLookup;
    // In the popup: tree item for "AI-OPS5".
    public final Locator aiOpsTreeItem;
    // "Current stage Authorize 3 of" label.
    public final Locator currentStageAuthorizeLabel;
    // "Approvers (6)" tab inside a tabs list.
    public final Locator approversTab;
    // "Open record: Bernard" element.
    public final Locator openRecordBernard;
    // "Back" button.
    public final Locator backButton;
    // "Requested - Open record: Change Request: CHG0000037" element.
    public final Locator requestedChangeRecord;

    public ExamplePage(Page page, SoftAssert softAssert, ExtentTest extentTest, Properties prop) {
        this.page = page;
        // Initialize the generic utils
        this.utils = new CommonPlaywrightActions(page, softAssert, extentTest);
        this.prop = prop;
        // Initialize the ServiceNowActions
        this.snActions = new serviceNowActions(page, softAssert, extentTest);
        // Initialize the frame locator for the iframe "gsft_main".
        this.gsftMainFrame = page.frameLocator("iframe[name='gsft_main']");

        // -------------------- Main Page --------------------
        bodyLocator = page.locator("body");

        userNameInput = page.getByLabel("User name");
        passwordInput = page.getByLabel("Password", new Page.GetByLabelOptions().setExact(true));
        loginButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Log in"));
        loginButtonAlt = page.locator("button").filter(new Locator.FilterOptions().setHasText("Log in"));

        landingPageLocator = page.getByLabel("My ServiceNow landing page");
        allLocator = page.getByLabel("All", new Page.GetByLabelOptions().setExact(true));
        filterInput = page.getByPlaceholder("Filter");
        
        menuLocator = page.getByLabel("Menu", new Page.GetByLabelOptions().setExact(true));
        scopeSelectorsLocator = page.getByLabel("Scope selectors");
        updateSetButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Update set: Default 1 [Global]"));
        userAvailabilityButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("IVS Testing_User: available"));
        closeDialogButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Close dialog"));

        preferencesMenuItem = page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Preferences"));
        preferencesLocator = page.getByLabel("Preferences", new Page.GetByLabelOptions().setExact(true));
        selectUserLocator = page.getByLabel("Select a user");
        selectUserComboBox = page.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("Select a user"));
        bernardOption = page.locator("[id=\"\\33 7gm9iqm51n1-1904-item-container\"]")
                           .getByRole(AriaRole.OPTION, new Locator.GetByRoleOptions().setName("Bernard Laboy Bernard bernard"));
        bernardRadioButton = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName("Bernard Bernard Bernard"));
        impersonateUserMenuItem = page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Impersonate user"));
        impersonateUserButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Impersonate user"));

        myTeamDashboardHeading = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("My Team dashboard"));
        changeDashboardLocator = page.getByLabel("Change dashboard");
        refreshDashboardLocator = page.getByLabel("Refresh dashboard");
        logoutMenuItem = page.getByRole(AriaRole.MENUITEM, new Page.GetByRoleOptions().setName("Log out"));
        myApprovalsLocator = page.getByLabel("My Approvals 1 of");

        invalidCredentialsMessage = page.getByText("User name or password invalid", new Page.GetByTextOptions().setExact(true));
        welcomeAdminHomeMessage = page.getByText("Welcome to Admin Home, IVS!");
        
        createNewRecordLocator = page.getByLabel("Create New 1 of");
        zoomModemButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Zoom V.92 USB Modem"));

        thirdServiceNowDiv = page.locator("div")
                                  .filter(new Locator.FilterOptions().setHasText(Pattern.compile("^ServiceNow$")))
                                  .nth(2);
        serviceNowSpan = page.locator("span")
                             .filter(new Locator.FilterOptions().setHasText(Pattern.compile("^ServiceNow$")));
        
        // -------------------- Within the gsft_main iframe --------------------
        aboutServiceNowHeading = gsftMainFrame.getByRole(AriaRole.HEADING, new FrameLocator.GetByRoleOptions().setName("About ServiceNow"));
        usingServiceNowHeading = gsftMainFrame.getByRole(AriaRole.HEADING, new FrameLocator.GetByRoleOptions().setName("Using ServiceNow"));
        emergencyIcon = gsftMainFrame.getByText("EmergencySVG/thumbtack-fill-");
        configItemLookup = gsftMainFrame.getByLabel("Look up value for field: Configuration item");
        shortDescriptionField = gsftMainFrame.getByLabel("Short description");
        justificationField = gsftMainFrame.getByLabel("Justification");
        implementationPlanField = gsftMainFrame.getByLabel("Implementation plan");
        riskImpactAnalysisField = gsftMainFrame.getByLabel("Risk and impact analysis");
        backoutPlanField = gsftMainFrame.getByLabel("Backout plan");
        testPlanField = gsftMainFrame.getByLabel("Test plan");
        scheduleTab = gsftMainFrame.getByLabel("Section Tab Lists").getByText("Schedule");
        selectPlannedStartDateButton = gsftMainFrame.getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Select Planned start date"));
        saturdayMarch8Date = gsftMainFrame.getByLabel("Saturday, March 8,");
        timeHourField = gsftMainFrame.getByLabel("Time: Hour");
        saveEnterButton = gsftMainFrame.getByLabel("Save (Enter)");
        selectPlannedEndDateButton = gsftMainFrame.getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Select Planned end date date"));
        mondayMarch10Date = gsftMainFrame.getByLabel("Monday, March 10,");
        additionalActionsMenu = gsftMainFrame.getByLabel("additional actions menu");
        saveMenuItem = gsftMainFrame.getByRole(AriaRole.MENUITEM, new FrameLocator.GetByRoleOptions().setName("Save"));
        changeRequestTypeField = gsftMainFrame.getByLabel("Change Request form section").getByLabel("Type");
        changeRequestStateField = gsftMainFrame.getByLabel("Change Request form section").getByLabel("State");
        stateModelRequestCabApproval = gsftMainFrame.locator("#state_model_request_cab_approval");
        mandatoryTextMessage = gsftMainFrame.getByText("The following mandatory");
        assignmentGroupLookup = gsftMainFrame.getByLabel("Look up value for field: Assignment group");
        aiOpsTreeItem = page.getByRole(AriaRole.TREEITEM, new Page.GetByRoleOptions().setName("AI-OPS5"));
        currentStageAuthorizeLabel = gsftMainFrame.getByLabel("Current stage Authorize 3 of");
        approversTab = gsftMainFrame.locator("#tabs2_list").getByText("Approvers (6)");
        openRecordBernard = gsftMainFrame.getByLabel("Open record: Bernard");
        backButton = gsftMainFrame.getByLabel("Back");
        requestedChangeRecord = gsftMainFrame.getByLabel("Requested - Open record: Change Request: CHG0000037");
    }
    public void login(String username, String password) {
    	snActions.navigateToURL(prop.getProperty("baseUrl"));
        utils.EnterText(userNameInput, username, "Username Field");
        utils.EnterText(passwordInput, password, "Password Field");
        utils.ClickElement(loginButton, "Login Button");
    }
    public void navigateToChangeCreateNew() {
        // Using serviceNowActions method for demonstration:
        snActions.clickElementByLabel("All", true);
        snActions.fillTextByPlaceholder("Filter", "change");
        snActions.clickElementByLabel("Create New 1 of", true);
    }
    
}

