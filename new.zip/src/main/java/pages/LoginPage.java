package pages;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.WaitForSelectorState;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class LoginPage {
    private final Page page;

    // Locators
    private final String usernameField = "input[name='user_name']";
    private final String passwordField = "input[name='user_password']";
    private final String loginButton = "button#sysverb_login";
    private final String welcomeText = "text=Welcome to Admin Home, IVS!"; 
    private final String errorMessage = "text=User name or password invalid";

    public LoginPage(Page page) {
        this.page = page;
    }

    public void login(String username, String password) {
        page.waitForLoadState(LoadState.NETWORKIDLE); // Wait for page to fully load
        page.fill(usernameField, username);
        page.fill(passwordField, password);
        page.click(loginButton);

        // Wait for either success or failure
        boolean loginSuccess = page.waitForSelector(welcomeText, new Page.WaitForSelectorOptions()
            .setState(WaitForSelectorState.VISIBLE)
            .setTimeout(10000)) != null;

        boolean loginFailed = page.waitForSelector(errorMessage, new Page.WaitForSelectorOptions()
            .setState(WaitForSelectorState.VISIBLE)
            .setTimeout(5000)) != null;

        if (loginFailed) {
            System.out.println("Login failed: Invalid username or password.");
        }
    }

    public boolean isLoginSuccessful() {
        return page.locator(welcomeText).isVisible();
    }
}
