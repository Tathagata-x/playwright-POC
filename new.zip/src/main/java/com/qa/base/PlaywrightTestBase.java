package com.qa.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.testng.ITestResult;
import org.testng.annotations.*;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.microsoft.playwright.*;

public class PlaywrightTestBase {
    public static Playwright playwright;
    public static Browser browser;
    public static BrowserContext context;
    public static Page page;
    public static Properties prop;
    public static ExtentReports extent;
    public static ExtentTest extentTest;
    public static String currentDateTime;

    public PlaywrightTestBase() {
        prop = new Properties();
        try (FileInputStream ip = new FileInputStream("src/test/resources/com/qa/config/config.properties")) {
            prop.load(ip);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load configuration file.", e);
        }
    }


    @BeforeSuite
    public void setReport() {
        currentDateTime = new SimpleDateFormat("MM-dd-yyyy_HH-mm-ss").format(new Date());
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter("./Reports/SalesForceEBEN_Playwright_" + currentDateTime + ".html");
        sparkReporter.config().setReportName("SalesForceEBEN Playwright Test Report");
        sparkReporter.config().setDocumentTitle("Automation Execution Report");

        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);
        extent.setSystemInfo("Environment", "FT Server");
        extent.setSystemInfo("Browser", prop.getProperty("browser"));
        extent.setSystemInfo("OS", "Windows 10");
    }

    @BeforeMethod
    public void setUp() {
        playwright = Playwright.create();
        String browserType = prop.getProperty("browser").toLowerCase();

        switch (browserType) {
            case "chrome":
                browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
                break;
            case "firefox":
                browser = playwright.firefox().launch(new BrowserType.LaunchOptions().setHeadless(false));
                break;
            case "edge":
                browser = playwright.webkit().launch(new BrowserType.LaunchOptions().setHeadless(false));
                break;
            default:
                throw new IllegalArgumentException("Unsupported browser: " + browserType);
        }

        context = browser.newContext();
        page = context.newPage();
        page.navigate(prop.getProperty("URL"));
    }

    @AfterMethod
    public void tearDown(ITestResult result) throws IOException {
        String methodName = result.getName();
        if (result.getStatus() == ITestResult.FAILURE) {
            extentTest.fail("<b><font color=red>Screenshot of Failure</font></b>", 
                MediaEntityBuilder.createScreenCaptureFromBase64String(takeScreenshot()).build());
            extentTest.fail(result.getThrowable());
            Markup m = MarkupHelper.createLabel("<b>Test Case " + methodName + " Failed</b>", ExtentColor.RED);
            extentTest.log(Status.FAIL, m);
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            Markup m = MarkupHelper.createLabel("<b>Test Case " + methodName + " Passed</b>", ExtentColor.GREEN);
            extentTest.log(Status.PASS, m);
        } else if (result.getStatus() == ITestResult.SKIP) {
            Markup m = MarkupHelper.createLabel("<b>Test Case " + methodName + " Skipped</b>", ExtentColor.ORANGE);
            extentTest.log(Status.SKIP, m);
        }

        if (context != null) {
            context.close();
        }
        if (browser != null) {
            browser.close();
        }
        if (playwright != null) {
            playwright.close();
        }
    }

    @AfterSuite
    public void endReport() {
        extent.flush();
    }

    public String takeScreenshot() {
        byte[] screenshotBytes = page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get("./screenshots/" + System.currentTimeMillis() + ".png")).setFullPage(true));
        return java.util.Base64.getEncoder().encodeToString(screenshotBytes);
    }
}
