package com.qa.utils;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.qa.base.PlaywrightTestBase;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.SelectOption;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class GenericFunction extends PlaywrightTestBase {
    private final Page page;

    public GenericFunction() {
        super();
        this.page = super.page; // Assuming base class provides Page instance
    }

    // ---------------------- Core Interaction Methods ----------------------

    public void ComboSelectValue(Locator element, String value, String description) {
        try {
            element.selectOption(new SelectOption().setValue(value));
            logSuccess(description, "Value '" + value + "' selected");
        } catch (Exception e) {
            handleError("select value", description, e);
        }
    }

    public void ComboSelectVisibleText(Locator element, String text, String description) {
        try {
            element.selectOption(new SelectOption().setLabel(text));
            logSuccess(description, "Text '" + text + "' selected");
        } catch (Exception e) {
            handleError("select visible text", description, e);
        }
    }

    public void EnterText(Locator element, String value, String description) {
        try {
            if (StringUtils.isNotBlank(value)) {
                element.fill(value.trim());
                logSuccess(description, "Entered '" + value + "'");
            } else {
                logFailure(description, "Empty value provided");
            }
        } catch (Exception e) {
            handleError("enter text", description, e);
        }
    }

    public void ClickElement(Locator element, String elementName) {
        try {
            element.click(new Locator.ClickOptions().setTimeout(10000));
            logSuccess(elementName, "Clicked successfully");
        } catch (Exception e) {
            handleError("click", elementName, e);
            takeScreenshot("ClickError_" + elementName);
        }
    }

    // ---------------------- Validation Methods ----------------------

    public boolean assertElementDisplayed(Locator element, String elementName) {
        try {
            element.waitFor(new Locator.WaitForOptions().setTimeout(5000));
            if (element.isVisible()) {
                logSuccess(elementName, "is displayed");
                return true;
            }
        } catch (Exception e) {
            logFailureWithScreenshot(elementName, "not displayed", e);
        }
        return false;
    }

    public boolean assertText(Locator element, String expectedText, String elementName) {
        try {
            String actualText = element.textContent().trim();
            if (actualText.equalsIgnoreCase(expectedText)) {
                logSuccess(elementName, "text matches: " + expectedText);
                return true;
            } else {
                logFailure(elementName, "text mismatch. Expected: " + expectedText + ", Actual: " + actualText);
            }
        } catch (Exception e) {
            logFailureWithScreenshot(elementName, "text validation failed", e);
        }
        return false;
    }

    // ---------------------- Utility Methods ----------------------

    public void takeScreenshot(String screenshotName) {
        try {
            String timestamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
            String path = "screenshots/" + screenshotName + "_" + timestamp + ".png";
            page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(path)));
            logInfo("Screenshot saved: " + path);
        } catch (Exception e) {
            logError("Failed to take screenshot", e);
        }
    }
    private void logInfo(String message) {
        // For example, print to console or use a logging framework
        System.out.println("[INFO] " + message);
    }

    private void logError(String message, Exception e) {
        System.err.println("[ERROR] " + message + ": " + e.getMessage());
        e.printStackTrace();
    }
    public void scrollToElement(Locator element, String description) {
        try {
            element.scrollIntoViewIfNeeded();
            logSuccess(description, "scrolled into view");
        } catch (Exception e) {
            handleError("scroll to", description, e);
        }
    }

    // ---------------------- Private Helpers ----------------------

    private void logSuccess(String element, String message) {
        extentTest.log(Status.PASS, element + " - " + message);
        System.out.println("[SUCCESS] " + element + ": " + message);
    }

    private void logFailure(String element, String message) {
        extentTest.log(Status.FAIL, element + " - " + message);
        System.out.println("[FAILURE] " + element + ": " + message);
    }

    private void logFailureWithScreenshot(String element, String message, Exception e) {
        String screenshotPath = takeScreenshotForReport("Error_" + element);
        try {
            extentTest.fail(element + " - " + message + ": " + e.getMessage(),
                    MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (Exception Ex) {
            extentTest.fail(element + " - " + message + " [Screenshot unavailable]");
        }
    }

    private String takeScreenshotForReport(String prefix) {
        String path = "screenshots/" + prefix + "_" + System.currentTimeMillis() + ".png";
        page.screenshot(new Page.ScreenshotOptions()
                .setPath(Paths.get(path))
                .setFullPage(true));
        return path;
    }

    private void handleError(String action, String element, Exception e) {
        String errorMsg = "Failed to " + action + " " + element + ": " + e.getMessage();
        System.err.println("[ERROR] " + errorMsg);
        extentTest.log(Status.FAIL, errorMsg);
        takeScreenshot("Error_" + action + "_" + element);
    }
}