package com.qa.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.microsoft.playwright.Page;
import com.qa.base.PlaywrightTestBase;

/**
 * TestUtils is a utility class with methods for reading Excel data 
 * and capturing screenshots via Playwright.
 */
public class TestUtils extends PlaywrightTestBase {

    // Timeouts (if needed)
    public static long PAGE_LOAD_TIMEOUT = 20;
    public static long IMPLICIT_WAIT = 15;

    // Excel-related fields
    private static Workbook book;
    private static Sheet sheet;

    // This reads the testdata_path key from config.properties
    // (Make sure your PlaywrightTestBase loads `prop` from the config file)
    public static String TestDataSheetPath = prop.getProperty("testdata_path");

    // Default constructor calls super(), so `prop` is loaded if the base does it.
    public TestUtils() {
        super();
    }

    /**
     * Reads data from an Excel sheet into a 2D array (Object[][]).
     * @param SheetName name of the worksheet within the Excel file.
     * @return 2D array of the sheet data.
     * @throws FileNotFoundException if the file is not found
     */
    public static Object[][] getSFTestData(String SheetName) throws FileNotFoundException {
        FileInputStream fis = null;
        try {
            System.out.println("Test Data File Path: " + TestDataSheetPath);
            fis = new FileInputStream(TestDataSheetPath);
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException("Test Data file not found at path: " + TestDataSheetPath);
        }

        try {
            book = WorkbookFactory.create(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return new Object[0][0];
        }

        sheet = book.getSheet(SheetName);
        if (sheet == null) {
            throw new IllegalArgumentException("Sheet '" + SheetName + "' not found in the Excel file.");
        }

        Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
        for (int i = 0; i < sheet.getLastRowNum(); i++) {
            for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
                if (sheet.getRow(i + 1).getCell(k) != null) {
                    data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
                } else {
                    data[i][k] = ""; // Handle null cell
                }
            }
        }
        return data;
    }

    // For naming screenshots
    protected static String testIDForScreenshot = "Test"; // default test ID

    /**
     * Takes a full-page screenshot using Playwright and saves it under Screenshots/.
     * @param screenshotName A label for the screenshot file name.
     */
    public static void takeScreenshot(String screenshotName) {
        String datetime = new SimpleDateFormat("MMddyyyyHHmmss").format(new Date());
        String filePath = "./Screenshots/" + testIDForScreenshot + "_" 
            + datetime + "_" + screenshotName.replaceAll("/", "_") + ".png";

        try {
            page.screenshot(new Page.ScreenshotOptions()
                .setPath(Paths.get(filePath))
                .setFullPage(true));
            System.out.println("Screenshot saved: " + filePath);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Cannot capture the screenshot");
        }
    }

    /**
     * Takes a screenshot as a byte array and returns it as a Base64-encoded string.
     * @return Base64 representation of the screenshot, or null if it fails.
     */
    public static String getScreenshotAsBase64() {
        try {
            byte[] screenshotBytes = page.screenshot();
            return Base64.getEncoder().encodeToString(screenshotBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Data caching for getExpectedData
    private static Object[][] data = null;
    private static String previousSheet = "";

    /**
     * Retrieves a list of values from the Excel data for a given testDataID (e.g., retrieving expected results).
     * @param sheetName The sheet to read from.
     * @param testDataID The identifier in the first column.
     * @return A list of strings for that test ID's row data.
     * @throws IOException if the sheet data can't be loaded
     */
    public static List<String> getExpectedData(String sheetName, String testDataID) throws IOException {
        if (data == null || !previousSheet.equalsIgnoreCase(sheetName)) {
            data = TestUtils.getSFTestData(sheetName);
            previousSheet = sheetName;
        }
        List<String> expectedData = new ArrayList<>();
        for (int i = 0; i < data.length; i++) {
            if (data[i][0].toString().equalsIgnoreCase(testDataID)) {
                expectedData.add(data[i][1].toString());
            }
        }
        return expectedData;
    }
}
