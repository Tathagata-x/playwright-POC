package tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.*;
import actions.serviceNowActions;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

public class EmergencyChangeTest {
    private Playwright playwright;
    private Browser browser;
    private BrowserContext context;
    private Page page;
    private SoftAssert softAssert;
    private serviceNowActions actions;
    private ExtentReports extentReports;
    private ExtentTest extentTest;

    @BeforeClass
    public void setUp() {
        // Initialize Playwright and launch browser
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
        context = browser.newContext();
        page = context.newPage();
     // Initialize ExtentReports and create a test entry
        extentReports = new ExtentReports();
        extentTest = extentReports.createTest("Emergency Change Flow Test");
        // Initialize SoftAssert and our custom ServiceNow actions
        softAssert = new SoftAssert();
        actions = new serviceNowActions(page, softAssert, extentTest);
    }

    @Test
    public void testEmergencyChangeFlow() {
        // Step 1: Login to ServiceNow with valid credentials
        actions.navigateToURL("https://pdsinfosysliveopsdemo2.service-now.com/");
        actions.fillTextByLabel("User name", "IVS_Testing_User", false);
        actions.fillTextByLabel("Password", "Demo@123", true);
        actions.clickElementByRole("BUTTON", "Log in");

        // Step 2: Redirected to the Home page (implicit if login is successful)

     // Step 3: Navigate to 'Change > Create New' via the filter navigation
        actions.clickElementByRole("MENUITEM", "All");
        actions.fillTextByPlaceholder("Filter", "change");

        // 4. Click on "Create New 1 of" (again, use exact match if needed)
        actions.clickElementByLabel("Create New 1 of", true);
        // Step 4: Select the model to create change request (assumes a label "Model" exists)
     // Click the Emergency tile by its visible text
        actions.clickElementByText("Emergency", true);


        // Step 5: New change request form is opened
        // (Here, wait or validate that the form is visible – implementation may vary)

        // Step 6: Fill all the required fields in the change request form
        // For example, fill in a short description and any other mandatory fields
        actions.fillTextByLabel("Short description", "Emergency Change Test", true);
        // ... fill other required fields as needed

        // Step 7: Save the form
        actions.clickElementByRole("BUTTON", "Save");

        // Step 8: Validate the change record is created successfully:
        //         Validate that the Type field value is 'Emergency' and State is 'New'
        boolean isTypeEmergency = actions.assertTextByLabel("Type", "Emergency", true);
        softAssert.assertTrue(isTypeEmergency, "Type field should be 'Emergency'");
        boolean isStateNew = actions.assertTextByLabel("State", "New", true);
        softAssert.assertTrue(isStateNew, "State field should be 'New'");

        // Step 9: Click on 'Request Approval' UI Action
        actions.clickElementByLabel("Request Approval", true);

        // Step 10: Validate error message is displayed and Assignment Group is mandatory
        boolean isErrorDisplayed = actions.verifyElementDisplayedByLabel("Error", false);
        softAssert.assertTrue(isErrorDisplayed, "Error message should be displayed indicating mandatory Assignment Group");

        // Step 11: Fill the Assignment Group value and save the form; the State should move to 'Authorize'
        actions.fillTextByLabel("Assignment group", "YourAssignmentGroup", true);
        actions.clickElementByRole("BUTTON", "Save");
        boolean isStateAuthorize = actions.assertTextByLabel("State", "Authorize", true);
        softAssert.assertTrue(isStateAuthorize, "State should be moved to 'Authorize'");

        // Step 12: Validate that approvers are triggered (e.g. an Approvers section is visible)
        boolean areApproversDisplayed = actions.verifyElementDisplayedByLabel("Approvers", false);
        softAssert.assertTrue(areApproversDisplayed, "Approvers should be triggered");

        // Step 13: Impersonate the approver 'Bernard'
        actions.clickElementByLabel("User Profile", true);
        actions.clickElementByLabel("Impersonate user", true);
        actions.fillTextByLabel("Select a user", "Bernard", true);
        actions.clickElementByRole("BUTTON", "Impersonate user");

        // Step 14: Navigate to 'My Approvals' table
        actions.clickElementByLabel("My Approvals", true);

        // Step 15: Search for the change request to approve
        actions.fillTextByPlaceholder("Search", "Emergency Change Test");
        actions.clickElementByLabel("Emergency Change Test", true); // Open the change record

        // Step 16: Approve the change request
        actions.clickElementByLabel("Approve", true);

        // Step 17: End impersonation
        actions.clickElementByLabel("End impersonation", true);

        // Step 18: Re-open the change request and validate its state has changed to 'Scheduled'
        actions.clickElementByLabel("Emergency Change Test", true);
        boolean isStateScheduled = actions.assertTextByLabel("State", "Scheduled", true);
        softAssert.assertTrue(isStateScheduled, "State should be changed to 'Scheduled'");

        // Step 19: Click on 'Implement' – State should be moved to 'Implement'
        actions.clickElementByLabel("Implement", true);
        boolean isStateImplement = actions.assertTextByLabel("State", "Implement", true);
        softAssert.assertTrue(isStateImplement, "State should be moved to 'Implement'");

        // Step 20: Change tasks are created; open the 'Post implementation testing' task
        actions.clickElementByLabel("Post implementation testing", true);
        // Fill required fields for the task (Assignment group, Planned start/end dates)
        actions.fillTextByLabel("Assignment group", "YourAssignmentGroup", true);
        actions.fillTextByLabel("Planned start date", "2025-03-20", true);
        actions.fillTextByLabel("Planned end date", "2025-03-21", true);
        actions.clickElementByRole("BUTTON", "Save");

        // Step 21: Click on 'Close task' – fill close code and close notes (mandatory)
        actions.clickElementByLabel("Close task", true);
        actions.fillTextByLabel("Close code", "Successful", true);
        actions.fillTextByLabel("Close notes", "Task closed", true);
        actions.clickElementByRole("BUTTON", "Close");

        // Step 22: Open the 'Implement Change' task and repeat the close task steps
        actions.clickElementByLabel("Implement Change", true);
        actions.fillTextByLabel("Assignment group", "YourAssignmentGroup", true);
        actions.fillTextByLabel("Planned start date", "2025-03-20", true);
        actions.fillTextByLabel("Planned end date", "2025-03-21", true);
        actions.clickElementByRole("BUTTON", "Save");
        actions.clickElementByLabel("Close task", true);
        actions.fillTextByLabel("Close code", "Successful", true);
        actions.fillTextByLabel("Close notes", "Task closed", true);
        actions.clickElementByRole("BUTTON", "Close");

        // Step 23: Change Request state is changed to 'Review'
        boolean isStateReview = actions.assertTextByLabel("State", "Review", true);
        softAssert.assertTrue(isStateReview, "State should be 'Review'");

        // Step 24: Click on 'Close Change Request'
        actions.clickElementByLabel("Close Change Request", true);
        // Fill mandatory close code and close notes, then close the change request
        actions.fillTextByLabel("Close code", "Successful", true);
        actions.fillTextByLabel("Close notes", "Change Request closed", true);
        actions.clickElementByRole("BUTTON", "Close");

        // Step 25: Validate the Change Request is closed successfully (State = 'Closed')
        boolean isChangeRequestClosed = actions.assertTextByLabel("State", "Closed", true);
        softAssert.assertTrue(isChangeRequestClosed, "Change Request should be closed successfully");
    }

    @AfterClass
    public void tearDown() {
        if (page != null) {
            page.close();
        }
        if (context != null) {
            context.close();
        }
        if (browser != null) {
            browser.close();
        }
        softAssert.assertAll();
        if (playwright != null) {
            playwright.close();
        }
    }
}
