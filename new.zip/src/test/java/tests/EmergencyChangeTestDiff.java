package tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.*;
import com.qa.base.PlaywrightTestBase;

import actions.serviceNowActions;
import pages.ExamplePage;

import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

public class EmergencyChangeTestDiff extends PlaywrightTestBase{
    private Playwright playwright;
    private Browser browser;
    private BrowserContext context;
    private Page page;
    private SoftAssert softAssert;
    private ExamplePage examplePage;
    private serviceNowActions actions;
    private ExtentReports extentReports;
    private ExtentTest extentTest;

    @BeforeClass
    public void setUp() {
        // Initialize Playwright and launch browser
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
        context = browser.newContext();
        page = context.newPage();
     // Initialize ExtentReports and create a test entry
        extentReports = new ExtentReports();
        extentTest = extentReports.createTest("Emergency Change Flow Test");
        // Initialize SoftAssert and our custom ServiceNow actions
        softAssert = new SoftAssert();
        examplePage = new ExamplePage(page, softAssert, extentTest, prop);
        actions = new serviceNowActions(page, softAssert, extentTest);
    }

    @Test
    public void testEmergencyChangeFlow() {
    	// Now you can call examplePage methods that internally use both utils and snActions
        examplePage.login(prop.getProperty("username"), prop.getProperty("password"));
        examplePage.navigateToChangeCreateNew();
    }

    @AfterClass
    public void tearDown() {
        if (page != null) {
            page.close();
        }
        if (context != null) {
            context.close();
        }
        if (browser != null) {
            browser.close();
        }
        softAssert.assertAll();
        if (playwright != null) {
            playwright.close();
        }
    }
}
